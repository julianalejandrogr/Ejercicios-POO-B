/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package main;
import Controlador.ControladorFigura;
import Controlador.ControladorCuadrado;
import Controlador.ControladorTriangulo;
import Modelo.FiguraGeometrica;
import Vista.JFFiguras;
import Vista.JFTriangulo;
import Vista.JFCuadrado;
import java.util.ArrayList;
/**
 *
 * @author Usuario
 */
public class Main {

    public static void main(String[] args) {
        ArrayList<FiguraGeometrica> listaFiguraComp = new ArrayList<>();
        
        JFFiguras frmFigura = new JFFiguras();
        frmFigura.setVisible(true);
        JFTriangulo frmTriangulo = new JFTriangulo();
        JFCuadrado frmCuadrado = new JFCuadrado();
        ControladorFigura ctrlFigura = new ControladorFigura(listaFiguraComp, frmFigura, frmTriangulo, frmCuadrado);
        ControladorCuadrado ctrlCuadrado = new ControladorCuadrado(frmCuadrado);
        ControladorTriangulo ctrlTriangulo = new ControladorTriangulo(frmTriangulo);
    }
}
