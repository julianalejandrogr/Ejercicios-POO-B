/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import Vista.JFFiguras;
import Vista.JFTriangulo;
import Vista.JFCuadrado;
import Modelo.FiguraGeometrica;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import java.awt.event.ActionListener;
public class ControladorFigura implements ActionListener{
    private ArrayList<FiguraGeometrica> listaFiguras;
    private JFCuadrado frmCuadrado;
    private JFFiguras frmFigura;
    private JFTriangulo frmTriangulo;

    public ControladorFigura(ArrayList<FiguraGeometrica> listaFiguras, JFFiguras frmFigura, JFTriangulo frmTriangulo, JFCuadrado frmCuadrado) {
        this.listaFiguras = listaFiguras;
        this.frmFigura = frmFigura;
        this.frmTriangulo = frmTriangulo;
        this.frmCuadrado = frmCuadrado;
        frmFigura.btnGuardar.addActionListener(this);
    }
    

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== frmFigura.btnGuardar){
            Guardar();
        }
        
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
   
    public void Guardar(){
        
       String lado = frmFigura.txtCantLados.getText();
        if(lado.isEmpty()){
           frmFigura.txtMensaje.setText("Digite todos los campos");
           return;
       }
       int lados= Integer.parseInt(frmFigura.txtCantLados.getText());
       if(lados < 3||lados> 4){
           frmFigura.txtMensaje.setText("Digite una figura valida (Triangulo o cuadrado)");
           return;
       }
       if(lados == 3){
           frmTriangulo.setVisible(true);
           
       }
       else if (lados==4){
           frmCuadrado.setVisible(true);
           
           
       }
    }
    
}
