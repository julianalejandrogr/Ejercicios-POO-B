/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import Controlador.ControladorFigura;
import Vista.JFCuadrado;
import Modelo.Cuadrado;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 *
 * @author Usuario
 */
public class ControladorCuadrado implements ActionListener{
    private JFCuadrado frmCuadrado;

    public ControladorCuadrado(JFCuadrado frmCuadrado) {
        this.frmCuadrado = frmCuadrado;
        frmCuadrado.btnGuardar.addActionListener(this);
    }
    
    

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource() == frmCuadrado.btnGuardar){
            GuardarCuadrado();
        }
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
     public void GuardarCuadrado(){
        int Lado1 = Integer.parseInt(frmCuadrado.txtLado1.getText());
        int Lado2 = Integer.parseInt(frmCuadrado.txtLado2.getText());
        int Lado3 = Integer.parseInt(frmCuadrado.txtLado3.getText());
        int Lado4 = Integer.parseInt(frmCuadrado.txtLado4.getText());
         if(Lado1 == Lado2 && Lado1 == Lado3 && Lado1 == Lado4){
           frmCuadrado.txtMensaje.setText("Es un cuadrado");
           }
           else if(Lado1 != Lado2 && Lado1 == Lado3 && Lado1 != Lado4|| Lado2 != Lado3 && Lado2 == Lado4 && Lado2 != Lado1){
            frmCuadrado.txtMensaje.setText("Es un rectángulo");
           }
    }
    
}
