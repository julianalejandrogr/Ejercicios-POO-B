/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 *
 * @author Estudiante
 */
public class JFWonderWoman extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(JFWonderWoman.class.getName());

    public JFWonderWoman() {
        initComponents();

        panelVista.setLayout(null);

        // ── Cargar imágenes ──
        ImageIcon iconoThemyscira  = new ImageIcon(getClass().getResource("/img/themyscira.jpg"));
        ImageIcon iconoLondres     = new ImageIcon(getClass().getResource("/img/londres.jpg"));
        ImageIcon iconoBatalla     = new ImageIcon(getClass().getResource("/img/campoGuerra.jpg"));
        ImageIcon iconoBunker      = new ImageIcon(getClass().getResource("/img/bunker.jpg"));
        ImageIcon iconoVictoria    = new ImageIcon(getClass().getResource("/img/victoria.jpg"));
        ImageIcon iconoDiana       = new ImageIcon(getClass().getResource("/img/diana.png"));
        ImageIcon iconoSteve       = new ImageIcon(getClass().getResource("/img/steve.png"));
        ImageIcon iconoAres        = new ImageIcon(getClass().getResource("/img/ares.png"));
        ImageIcon iconoSoldado     = new ImageIcon(getClass().getResource("/img/soldado.png"));

        // ── Escalar imágenes ──
        int pw = panelVista.getPreferredSize().width;
        int ph = panelVista.getPreferredSize().height;

        imgThemyscira = iconoThemyscira.getImage().getScaledInstance(pw, ph, Image.SCALE_SMOOTH);
        imgLondres    = iconoLondres.getImage().getScaledInstance(pw, ph, Image.SCALE_SMOOTH);
        imgBatalla    = iconoBatalla.getImage().getScaledInstance(pw, ph, Image.SCALE_SMOOTH);
        imgBunker     = iconoBunker.getImage().getScaledInstance(pw, ph, Image.SCALE_SMOOTH);
        imgVictoria   = iconoVictoria.getImage().getScaledInstance(pw, ph, Image.SCALE_SMOOTH);

        Image nDiana   = iconoDiana.getImage().getScaledInstance(70, 120, Image.SCALE_SMOOTH);
        Image nSteve   = iconoSteve.getImage().getScaledInstance(70, 120, Image.SCALE_SMOOTH);
        Image nAres    = iconoAres.getImage().getScaledInstance(80, 130, Image.SCALE_SMOOTH);
        Image nSoldado = iconoSoldado.getImage().getScaledInstance(70, 120, Image.SCALE_SMOOTH);

        // ── Asignar iconos a labels ──
        lblFondo.setIcon(new ImageIcon(imgThemyscira));
        lblDiana.setIcon(new ImageIcon(nDiana));
        lblSteve.setIcon(new ImageIcon(nSteve));
        lblAres.setIcon(new ImageIcon(nAres));
        lblSoldado.setIcon(new ImageIcon(nSoldado));

        // ── Posicionar labels ──
        lblFondo.setBounds(0, 0, pw, ph);
        lblDiana.setBounds(100, 320, 70, 120);
        lblSteve.setBounds(260, 320, 70, 120);
        lblAres.setBounds(580, 270, 80, 130);
        lblSoldado.setBounds(450, 330, 80, 80);
        lblEscenario.setBounds(10, 10, 160, 30);

        // ── Estilo del label de escenario ──
        lblEscenario.setOpaque(true);
        lblEscenario.setBackground(new java.awt.Color(0, 0, 0, 150));
        lblEscenario.setForeground(java.awt.Color.WHITE);
        lblEscenario.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));
        lblEscenario.setHorizontalAlignment(JLabel.CENTER);
        lblEscenario.setText("Themyscira");



        // ── Agregar al panel (orden: personajes encima, fondo al fondo) ──
        panelVista.add(lblEscenario);
        panelVista.add(lblDiana);
        panelVista.add(lblSteve);
        panelVista.add(lblAres);
        panelVista.add(lblSoldado);
        panelVista.add(lblFondo);

        panelVista.setComponentZOrder(lblFondo, panelVista.getComponentCount() - 1);

        // ── Visibilidad inicial ──
        lblFondo.setVisible(true);
        lblDiana.setVisible(false);
        lblSteve.setVisible(false);
        lblAres.setVisible(false);
        lblSoldado.setVisible(false);
        lblEscenario.setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        areaCuento = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        areaInfo = new javax.swing.JTextArea();
        panelVista = new javax.swing.JPanel();
        lblDiana = new javax.swing.JLabel();
        lblSteve = new javax.swing.JLabel();
        lblAres = new javax.swing.JLabel();
        lblSoldado = new javax.swing.JLabel();
        lblEscenario = new javax.swing.JLabel();
        lblFondo = new javax.swing.JLabel();
        btnAvanzar = new javax.swing.JButton();
        btnReiniciar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Wonder Woman", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 18), new java.awt.Color(0, 0, 204)));

        areaCuento.setColumns(20);
        areaCuento.setRows(5);
        areaCuento.setEditable(false);
        areaCuento.setLineWrap(true);
        areaCuento.setWrapStyleWord(true);
        jScrollPane1.setViewportView(areaCuento);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12));
        jLabel1.setText("Información de los Personajes");

        areaInfo.setColumns(20);
        areaInfo.setRows(5);
        areaInfo.setEditable(false);
        jScrollPane2.setViewportView(areaInfo);

        panelVista.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        panelVista.setPreferredSize(new java.awt.Dimension(950, 510));

        javax.swing.GroupLayout panelVistaLayout = new javax.swing.GroupLayout(panelVista);
        panelVista.setLayout(panelVistaLayout);
        panelVistaLayout.setHorizontalGroup(
            panelVistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelVistaLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(panelVistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblFondo)
                    .addComponent(lblDiana)
                    .addComponent(lblSteve)
                    .addComponent(lblAres)
                    .addComponent(lblSoldado)
                    .addComponent(lblEscenario))
                .addContainerGap(919, Short.MAX_VALUE))
        );
        panelVistaLayout.setVerticalGroup(
            panelVistaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelVistaLayout.createSequentialGroup()
                .addContainerGap(125, Short.MAX_VALUE)
                .addComponent(lblFondo)
                .addGap(18, 18, 18)
                .addComponent(lblEscenario)
                .addGap(18, 18, 18)
                .addComponent(lblDiana)
                .addGap(18, 18, 18)
                .addComponent(lblSteve)
                .addGap(18, 18, 18)
                .addComponent(lblAres)
                .addGap(18, 18, 18)
                .addComponent(lblSoldado)
                .addGap(50, 50, 50))
        );

        btnAvanzar.setText("Avanzar");
        btnReiniciar.setText("Reiniciar");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(btnAvanzar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnReiniciar, javax.swing.GroupLayout.DEFAULT_SIZE, 273, Short.MAX_VALUE))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(panelVista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 372, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(panelVista, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(34, 34, 34)
                                .addComponent(btnAvanzar)
                                .addGap(26, 26, 26)
                                .addComponent(btnReiniciar))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 503, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Imágenes de fondo (accesibles desde el controlador)
    public java.awt.Image imgThemyscira;
    public java.awt.Image imgLondres;
    public java.awt.Image imgBatalla;
    public java.awt.Image imgBunker;
    public java.awt.Image imgVictoria;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JTextArea areaCuento;
    public javax.swing.JTextArea areaInfo;
    public javax.swing.JButton btnAvanzar;
    public javax.swing.JButton btnReiniciar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    public javax.swing.JLabel lblDiana;
    public javax.swing.JLabel lblSteve;
    public javax.swing.JLabel lblAres;
    public javax.swing.JLabel lblSoldado;
    public javax.swing.JLabel lblEscenario;
    public javax.swing.JLabel lblFondo;
    public javax.swing.JPanel panelVista;
    // End of variables declaration//GEN-END:variables
}
