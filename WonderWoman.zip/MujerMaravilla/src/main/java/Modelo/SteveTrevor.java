/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Estudiante
 */
public class SteveTrevor extends Personaje {
    private String rango;
    private String estado;
    private boolean vivo;

    public SteveTrevor() {
    }

    public SteveTrevor(String rango, String estado, boolean vivo, String nombre, String tipo, String caracteristica) {
        super(nombre, tipo, caracteristica);
        this.rango = rango;
        this.estado = estado;
        this.vivo = vivo;
    }

    public String getRango() {
        return rango;
    }

    public void setRango(String rango) {
        this.rango = rango;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public boolean isVivo() {
        return vivo;
    }

    public void setVivo(boolean vivo) {
        this.vivo = vivo;
    }

    @Override
    public String toString() {
        return "\nNombre = " + nombre
                + "\nRol = " + tipo
                + "\nCaracteristica = " + caracteristica
                + "\nRango = " + rango
                + "\nEstado = " + estado
                + "\nVivo? = " + vivo;
    }
}
