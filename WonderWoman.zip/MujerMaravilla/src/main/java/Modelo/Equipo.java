/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Estudiante
 */
public class Equipo {
    private boolean lazoVerdad = false;
    private boolean escudoAtenea = false;
    private boolean espadaGal = false;

    public Equipo() {
    }

    public Equipo(boolean lazoVerdad, boolean escudoAtenea, boolean espadaGal) {
        this.lazoVerdad = lazoVerdad;
        this.escudoAtenea = escudoAtenea;
        this.espadaGal = espadaGal;
    }

    public boolean isLazoVerdad() {
        return lazoVerdad;
    }

    public void setLazoVerdad(boolean lazoVerdad) {
        this.lazoVerdad = lazoVerdad;
    }

    public boolean isEscudoAtenea() {
        return escudoAtenea;
    }

    public void setEscudoAtenea(boolean escudoAtenea) {
        this.escudoAtenea = escudoAtenea;
    }

    public boolean isEspadaGal() {
        return espadaGal;
    }

    public void setEspadaGal(boolean espadaGal) {
        this.espadaGal = espadaGal;
    }

    @Override
    public String toString() {
        return "Equipo\nLazo de la Verdad = " + lazoVerdad
                + "\nEscudo de Atenea = " + escudoAtenea
                + "\nEspada Gal = " + espadaGal;
    }
}
