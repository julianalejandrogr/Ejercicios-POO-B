/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Estudiante
 */
public class Soldado extends Personaje {
    private String arma;
    private boolean vivo;

    public Soldado() {
    }

    public Soldado(String arma, boolean vivo, String nombre, String tipo, String caracteristica) {
        super(nombre, tipo, caracteristica);
        this.arma = arma;
        this.vivo = vivo;
    }

    public String getArma() {
        return arma;
    }

    public void setArma(String arma) {
        this.arma = arma;
    }

    public boolean isVivo() {
        return vivo;
    }

    public void setVivo(boolean vivo) {
        this.vivo = vivo;
    }

    @Override
    public String toString() {
        return "\nNombre = " + nombre
                + "\nRol = " + tipo
                + "\nCaracteristica = " + caracteristica
                + "\nArma = " + arma
                + "\nVivo? = " + vivo;
    }
}
