/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Estudiante
 */
public class Combate {

    private Diana diana;
    private Ares ares;
    private Soldado soldado;

    public Combate(Diana diana, Ares ares, Soldado soldado) {
        this.diana = diana;
        this.ares = ares;
        this.soldado = soldado;
    }

    /**
     * Combate 1 - Diana vs soldados enemigos en el frente de guerra.
     * Diana bloquea las balas con sus brazaletes y derriba al soldado.
     */
    public String combateSoldados() {
        diana.setEstado("En combate");
        soldado.setVivo(false);
        return "[Diana usó sus brazaletes - soldado derribado]";
    }

    /**
     * Combate 2 - Diana vs Ludendorff en la base enemiga.
     * Diana ataca con la Espada Gal y reduce la vida de Ares en 40.
     */
    public String combateLudendorff() {
        ares.setVida(ares.getVida() - 40);
        ares.setEstado("Herido leve");
        return "[Diana atacó con la Espada Gal]\n[Ludendorff recibió el impacto - derrotado]";
    }

    /**
     * Combate 3 - Combate final Diana vs Ares.
     * Diana canaliza el poder de Zeus: pierde 20 de vida pero destruye a Ares.
     */
    public String combateFinalAres() {
        diana.setVida(diana.getVida() - 20);
        diana.setEstado("Poder máximo desbloqueado");
        ares.setVida(ares.getVida() - 60);
        ares.setEstado("Gravemente herido");
        return "[Diana canaliza el poder de Zeus - ATAQUE DEFINITIVO]";
    }

    /**
     * Finaliza el juego marcando a Ares como derrotado y a Diana como victoriosa.
     */
    public String victoria() {
        ares.setVivo(false);
        ares.setVida(0);
        ares.setEstado("Derrotado");
        diana.setEstado("Victoriosa");
        return "[Ares ha sido derrotado]";
    }
}
