/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Estudiante
 */
public class Diana extends Personaje {
    private String origen;
    private String estado;
    private int vida;
    private Equipo equipo;

    public Diana() {
    }

    public Diana(String origen, String estado, int vida, Equipo equipo, String nombre, String tipo, String caracteristica) {
        super(nombre, tipo, caracteristica);
        this.origen = origen;
        this.estado = estado;
        this.vida = vida;
        this.equipo = equipo;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    @Override
    public String toString() {
        return "\nNombre = " + nombre
                + "\nRol = " + tipo
                + "\nOrigen = " + origen
                + "\nCaracteristica = " + caracteristica
                + "\nVida = " + vida
                + "\nEstado = " + estado
                + "\n" + equipo.toString();
    }
}
