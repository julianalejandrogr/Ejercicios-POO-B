/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Estudiante
 */
public abstract class Personaje {
    protected String nombre;
    protected String tipo;
    protected String caracteristica;

    public Personaje() {
    }

    public Personaje(String nombre, String tipo, String caracteristica) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.caracteristica = caracteristica;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCaracteristica() {
        return caracteristica;
    }

    public void setCaracteristica(String caracteristica) {
        this.caracteristica = caracteristica;
    }

    @Override
    public String toString() {
        return "Personaje{" + "nombre=" + nombre + ", tipo=" + tipo + '}';
    }
}
