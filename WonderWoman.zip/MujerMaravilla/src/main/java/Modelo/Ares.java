/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Estudiante
 */
public class Ares extends Personaje {
    private String poder;
    private int vida;
    private boolean vivo;
    private String estado;

    public Ares() {
    }

    public Ares(String poder, int vida, boolean vivo, String estado, String nombre, String tipo, String caracteristica) {
        super(nombre, tipo, caracteristica);
        this.poder = poder;
        this.vida = vida;
        this.vivo = vivo;
        this.estado = estado;
    }

    public String getPoder() {
        return poder;
    }

    public void setPoder(String poder) {
        this.poder = poder;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public boolean isVivo() {
        return vivo;
    }

    public void setVivo(boolean vivo) {
        this.vivo = vivo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "\nNombre = " + nombre
                + "\nRol = " + tipo
                + "\nCaracteristica = " + caracteristica
                + "\nPoder = " + poder
                + "\nVida = " + vida
                + "\nEstado = " + estado
                + "\nVivo? = " + vivo;
    }
}
