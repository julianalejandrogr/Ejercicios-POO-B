/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package Main;

import Vista.JFWonderWoman;
import Controlador.ControladorWonderWoman;

/**
 *
 * @author Estudiante
 */
public class MujerMaravilla {

    public static void main(String[] args) {
        JFWonderWoman frmWW = new JFWonderWoman();
        frmWW.setVisible(true);
        ControladorWonderWoman ctrlWW = new ControladorWonderWoman(frmWW);
    }
}
