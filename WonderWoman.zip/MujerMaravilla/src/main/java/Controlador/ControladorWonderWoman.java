/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Vista.JFWonderWoman;
import Modelo.Diana;
import Modelo.Equipo;
import Modelo.SteveTrevor;
import Modelo.Ares;
import Modelo.Soldado;
import Modelo.Combate;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;

/**
 *
 * @author Estudiante
 */
public class ControladorWonderWoman implements ActionListener {

    private String msg = "";
    private int contador = 0;
    private JFWonderWoman frmWW;
    private Equipo equipo;
    private Diana diana;
    private SteveTrevor steve;
    private Ares ares;
    private Soldado soldado;
    private Combate combate;

    public ControladorWonderWoman(JFWonderWoman frmWW) {
        this.frmWW = frmWW;
        this.frmWW.btnAvanzar.addActionListener(this);
        this.frmWW.btnReiniciar.addActionListener(this);

        this.equipo = new Equipo(false, false, false);
        this.diana = new Diana("Themyscira", "Lista para la batalla", 100, equipo,
                "Diana Prince", "Protagonista",
                "Princesa amazona con\nfuerza y velocidad sobrehumanas");
        this.steve = new SteveTrevor("Capitan", "Activo", true,
                "Steve Trevor", "Aliado",
                "Espía y piloto de la\nPrimera Guerra Mundial");
        this.ares = new Ares("Control mental de la guerra", 100, true, "Poderoso",
                "Ares", "Villano Principal",
                "Dios de la guerra,\nhermano de Diana");
        this.soldado = new Soldado("Rifle", true,
                "Soldado enemigo", "Enemigo",
                "Combatiente al servicio\nde las fuerzas de Ares");
        this.combate = new Combate(diana, ares, soldado);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmWW.btnAvanzar) {
            avanzarJuego();
            contador++;
        }
        if (e.getSource() == frmWW.btnReiniciar) {
            reiniciarJuego();
            contador = 0;
        }
    }

    // Método auxiliar para cambiar el fondo
    private void cambiarFondo(java.awt.Image imagen) {
        frmWW.lblFondo.setIcon(new ImageIcon(imagen));
    }

    public void avanzarJuego() {
        switch (contador) {

            // ── ESCENA 1: Presentación en Themyscira ──
            case 0:
                cambiarFondo(frmWW.imgThemyscira);
                frmWW.lblEscenario.setText("Themyscira");
                frmWW.lblDiana.setVisible(true);
                frmWW.lblDiana.setBounds(100, 320, 70, 120);
                frmWW.areaCuento.append("En la isla oculta de Themyscira, hogar de las amazonas,\n"
                        + "vive Diana, hija de la reina Hipólita. Desde pequeña\n"
                        + "fue entrenada como guerrera por su tía Antíope, la\n"
                        + "mejor luchadora de todas las amazonas.\n"
                        + "Diana sueña con conocer el mundo más allá del mar...\n");
                msg += diana.toString();
                frmWW.areaInfo.setText(msg);
                break;

            // ── ESCENA 2: Llega Steve Trevor ──
            case 1:
                frmWW.lblSteve.setVisible(true);
                frmWW.lblSteve.setBounds(260, 320, 70, 120);
                frmWW.areaCuento.append("\nUn día, un avión cae al mar cerca de la isla.\n"
                        + "Diana se lanza al agua y rescata al piloto: Steve Trevor,\n"
                        + "un espía aliado que huye de las tropas alemanas.\n"
                        + "Steve le cuenta a Diana sobre la Gran Guerra que\n"
                        + "asola al mundo exterior. Diana está convencida:\n"
                        + "Ares, el dios de la guerra, está detrás de todo.\n");
                msg += "\n" + steve.toString();
                frmWW.areaInfo.setText(msg);
                break;

            // ── ESCENA 3: Diana decide partir ──
            case 2:
                equipo.setEspadaGal(true);
                diana.setEquipo(equipo);
                frmWW.lblDiana.setBounds(180, 320, 70, 120);
                frmWW.areaCuento.append("\nContra la voluntad de su madre, Diana decide partir\n"
                        + "hacia el mundo de los hombres junto a Steve.\n"
                        + "Toma consigo la legendaria Espada Gal, conocida como\n"
                        + "el Destructor de Dioses, creyendo que es el arma\n"
                        + "para derrotar a Ares.\n");
                msg = diana.toString();
                frmWW.areaInfo.setText(msg);
                break;

            // ── ESCENA 4: Londres ──
            case 3:
                cambiarFondo(frmWW.imgLondres);
                frmWW.lblEscenario.setText("Londres, 1918");
                frmWW.lblDiana.setBounds(220, 320, 70, 120);
                frmWW.lblSteve.setBounds(340, 320, 70, 120);
                frmWW.areaCuento.append("\nDiana y Steve llegan a Londres. La ciudad está sumida\n"
                        + "en la guerra. Diana se sorprende con todo lo que ve:\n"
                        + "nunca habia salido de Themyscira.\n"
                        + "Steve le pide que disimule, pero Diana no está dispuesta\n"
                        + "a quedarse de brazos cruzados.\n"
                        + "Steve: \"El mundo no funciona así, Diana.\"\n"
                        + "Diana: \"Donde hay injusticia, debo actuar.\"\n");
                msg = diana.toString() + "\n" + steve.toString();
                frmWW.areaInfo.setText(msg);
                break;

            // ── ESCENA 5: Primer combate ──
            case 4:
                cambiarFondo(frmWW.imgBatalla);
                frmWW.lblEscenario.setText("Frente de guerra");
                frmWW.lblSoldado.setVisible(true);
                frmWW.lblSoldado.setBounds(500, 330, 80, 80);
                frmWW.lblDiana.setBounds(150, 320, 70, 120);
                frmWW.lblSteve.setBounds(280, 320, 70, 120);
                frmWW.areaCuento.append("\n¡COMBATE! Diana y Steve llegan al frente de batalla.\n"
                        + "Un grupo de soldados enemigos ataca la trinchera aliada.\n"
                        + "Diana: \"¡No puedo quedarme aquí!\"\n"
                        + "Sin dudarlo, Diana salta de la trinchera y avanza\n"
                        + "bloqueando las balas con sus brazaletes de adamantio.\n"
                        + combate.combateSoldados() + "\n");
                msg = diana.toString() + "\n" + steve.toString() + "\n" + soldado.toString();
                frmWW.areaInfo.setText(msg);
                break;

            // ── ESCENA 6: Obtiene el Lazo de la Verdad ──
            case 5:
                equipo.setLazoVerdad(true);
                diana.setEquipo(equipo);
                frmWW.lblSoldado.setVisible(false);
                frmWW.lblDiana.setBounds(300, 310, 70, 120);
                frmWW.areaCuento.append("\nTras la batalla, Diana recupera de los escombros\n"
                        + "el Lazo de la Verdad, que obliga a quien lo toque\n"
                        + "a decir solo la verdad.\n"
                        + "Steve queda atrapado en él por accidente y confiesa\n"
                        + "que nunca habia conocido a nadie como ella.\n"
                        + "Diana sonríe: el lazo no miente.\n");
                msg = diana.toString() + "\n" + steve.toString();
                frmWW.areaInfo.setText(msg);
                break;

            // ── ESCENA 7: Pista sobre Ares ──
            case 6:
                frmWW.lblEscenario.setText("Campamento aliado");
                frmWW.areaCuento.append("\nSteve y Diana interrogan a un prisionero\n"
                        + "usando el Lazo de la Verdad.\n"
                        + "El hombre confiesa: el General Ludendorff está\n"
                        + "desarrollando un gas venenoso devastador.\n"
                        + "Diana está convencida: Ludendorff ES Ares disfrazado.\n"
                        + "Steve: \"Es un general humano, Diana.\"\n"
                        + "Diana: \"El Lazo nunca miente. Yo lo detendré.\"\n");
                msg = diana.toString() + "\n" + steve.toString();
                frmWW.areaInfo.setText(msg);
                break;

            // ── ESCENA 8: Obtiene el Escudo de Atenea ──
            case 7:
                equipo.setEscudoAtenea(true);
                diana.setEquipo(equipo);
                frmWW.areaCuento.append("\nDiana encuentra entre los escombros de un templo\n"
                        + "el Escudo de Atenea, capaz de repeler cualquier ataque.\n"
                        + "Con el Lazo, el Escudo y la Espada Gal, Diana tiene\n"
                        + "el equipo completo de una guerrera amazona.\n"
                        + "Steve: \"Ahora sí pareces una diosa de verdad.\"\n");
                msg = diana.toString();
                frmWW.areaInfo.setText(msg);
                break;

            // ── ESCENA 9: Combate con Ludendorff ──
            case 8:
                cambiarFondo(frmWW.imgBunker);
                frmWW.lblEscenario.setText("Base enemiga");
                frmWW.lblAres.setVisible(true);
                frmWW.lblAres.setBounds(580, 260, 80, 130);
                frmWW.lblDiana.setBounds(200, 310, 70, 120);
                frmWW.lblSteve.setBounds(330, 310, 70, 120);
                frmWW.areaCuento.append("\n¡COMBATE! Diana irrumpe en la base enemiga.\n"
                        + "Encuentra a Ludendorff y lo enfrenta.\n"
                        + combate.combateLudendorff() + "\n"
                        + "Pero algo está mal: la guerra no se detiene.\n"
                        + "Diana: \"¿Por qué no se acaba la guerra?\"\n");
                msg = diana.toString() + "\n" + ares.toString();
                frmWW.areaInfo.setText(msg);
                break;

            // ── ESCENA 10: Revelación de Ares ──
            case 9:
                frmWW.lblAres.setBounds(420, 260, 80, 130);
                frmWW.lblDiana.setBounds(220, 310, 70, 120);
                frmWW.areaCuento.append("\nDe repente aparece Sir Patrick, el político aliado.\n"
                        + "Se quita la máscara: ¡ES ARES, el verdadero dios de la guerra!\n"
                        + "Ares: \"Yo no creo la guerra. Solo susurro ideas a los\n"
                        + "humanos. Ellos la eligen por sí solos.\"\n"
                        + "Ares destruye la Espada Gal con un rayo.\n"
                        + "Diana: \"¿Entonces no era la espada el arma?\"\n"
                        + "Ares: \"Tú eres el arma, Diana. Eres hija de Zeus.\"\n");
                ares.setEstado("Revelado");
                msg = diana.toString() + "\n" + ares.toString();
                frmWW.areaInfo.setText(msg);
                break;

            // ── ESCENA 11: Muerte de Steve ──
            case 10:
                frmWW.lblSteve.setBounds(700, 80, 70, 120);
                frmWW.areaCuento.append("\nMientras Diana enfrenta a Ares, Steve descubre\n"
                        + "el avión cargado con gas venenoso listo para despegar.\n"
                        + "Steve le entrega su reloj a Diana:\n"
                        + "\"Yo puedo salvar hoy. Tú puedes salvar el mundo.\"\n"
                        + "Steve sube al avión y lo hace estallar en el aire,\n"
                        + "sacrificándose para salvar miles de vidas.\n"
                        + "[Steve Trevor ha caído como un héroe]\n");
                steve.setVivo(false);
                steve.setEstado("Caído en combate");
                msg = diana.toString() + "\n" + steve.toString();
                frmWW.areaInfo.setText(msg);
                break;

            // ── ESCENA 12: Combate final con Ares ──
            case 11:
                frmWW.lblSteve.setVisible(false);
                frmWW.lblAres.setBounds(500, 260, 80, 130);
                frmWW.lblDiana.setBounds(230, 300, 70, 120);
                frmWW.areaCuento.append("\n¡COMBATE FINAL! Diana, devastada por la muerte de Steve,\n"
                        + "siente una furia enorme. Ares intenta tentarla:\n"
                        + "\"Únete a mí. Los humanos no merecen ser salvados.\"\n"
                        + "Diana mira a su alrededor: personas que se ayudan.\n"
                        + "Recuerda las palabras de Steve.\n"
                        + "Diana: \"Es sobre lo que crees. Yo creo en el amor.\"\n"
                        + combate.combateFinalAres() + "\n");
                msg = diana.toString() + "\n" + ares.toString();
                frmWW.areaInfo.setText(msg);
                break;

            // ── ESCENA 13: Victoria ──
            case 12:
                cambiarFondo(frmWW.imgVictoria);
                frmWW.lblEscenario.setText("Victoria");
                frmWW.lblAres.setVisible(false);
                frmWW.lblDiana.setBounds(420, 290, 70, 120);
                frmWW.areaCuento.append("\nDiana lanza todo su poder contra Ares.\n"
                        + "Un destello de luz dorada ilumina el campo de batalla.\n"
                        + combate.victoria() + "\n"
                        + "Con la derrota de Ares, el influjo de guerra disminuye.\n"
                        + "Los soldados se rinden. La Gran Guerra ha terminado.\n"
                        + "Diana llora a Steve, pero sabe que valió la pena.\n");
                msg = diana.toString() + "\n" + ares.toString();
                frmWW.areaInfo.setText(msg);
                break;

            // ── ESCENA 14: Epílogo ──
            case 13:
                frmWW.lblEscenario.setText("París, años después");
                frmWW.areaCuento.append("\nAños después, Diana sigue protegiendo al mundo\n"
                        + "desde las sombras. Trabaja como curadora en el\n"
                        + "Museo del Louvre en París.\n"
                        + "Nunca olvida a Steve Trevor, cuyo reloj guarda\n"
                        + "con cariño. Su sacrificio le recuerda todos los días\n"
                        + "por qué vale la pena creer en los seres humanos.\n\n"
                        + "\"Fui una guerrera. Ahora elijo ser algo más.\"\n"
                        + "                              - Diana Prince\n");
                diana.setEstado("Guardiana del mundo");
                msg = diana.toString();
                frmWW.areaInfo.setText(msg);
                frmWW.btnAvanzar.setEnabled(false);
                break;
        }
    }

    public void reiniciarJuego() {
        equipo = new Equipo(false, false, false);
        diana = new Diana("Themyscira", "Lista para la batalla", 100, equipo,
                "Diana Prince", "Protagonista",
                "Princesa amazona con\nfuerza y velocidad sobrehumanas");
        steve = new SteveTrevor("Capitan", "Activo", true,
                "Steve Trevor", "Aliado",
                "Espía y piloto de la\nPrimera Guerra Mundial");
        ares = new Ares("Control mental de la guerra", 100, true, "Poderoso",
                "Ares", "Villano Principal",
                "Dios de la guerra,\nhermano de Diana");
        this.soldado = new Soldado("Rifle", true,
                "Soldado enemigo", "Enemigo",
                "Combatiente al servicio\nde las fuerzas de Ares");
        this.combate = new Combate(diana, ares, soldado);

        // Reiniciar fondo y escenario
        frmWW.lblFondo.setIcon(new ImageIcon(frmWW.imgThemyscira));
        frmWW.lblEscenario.setText("Themyscira");

        // Reiniciar posiciones
        frmWW.lblDiana.setBounds(100, 320, 70, 120);
        frmWW.lblSteve.setBounds(260, 320, 70, 120);
        frmWW.lblAres.setBounds(580, 260, 80, 130);
        frmWW.lblSoldado.setBounds(450, 330, 80, 80);

        // Reiniciar visibilidad
        frmWW.lblDiana.setVisible(false);
        frmWW.lblSteve.setVisible(false);
        frmWW.lblAres.setVisible(false);
        frmWW.lblSoldado.setVisible(false);
        frmWW.lblEscenario.setVisible(true);

        // Limpiar textos
        msg = "";
        frmWW.areaCuento.setText("");
        frmWW.areaInfo.setText("");
        frmWW.btnAvanzar.setEnabled(true);
    }
}
