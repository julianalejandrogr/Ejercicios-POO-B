package Modelo;

/**
 *
 * @author USER
 */
public class Producto {
    private String tipo;
    private int puntos;

    public Producto() {
    }

    public Producto(String tipo, int puntos) {
        this.tipo = tipo;
        this.puntos = puntos;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    @Override
    public String toString() {
        return "Producto \ntipo= " + tipo + ", puntos= " + puntos;
    }
    
}
