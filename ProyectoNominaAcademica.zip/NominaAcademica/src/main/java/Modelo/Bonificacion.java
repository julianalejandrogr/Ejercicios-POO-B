package Modelo;

/**
 *
 * @author fabian
 */
public class Bonificacion {
    private Empleado empleado;
    private String id;
    private String descripcion;
    private double valor;

    public Bonificacion() {
    }

    public Bonificacion(Empleado empleado, String id,String descripcion) {
        this.empleado = empleado;
        this.id = id;
        this.descripcion = descripcion;
    }

    public Bonificacion(Empleado empleado, String id,String descripcion, double valor) {
        this.empleado = empleado;
        this.id = id;
        this.descripcion = descripcion;
        this.valor = valor;
    }

    public Empleado getEmpleado() {
        return empleado;
    }

    public void setEmpleado(Empleado empleado) {
        this.empleado = empleado;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String toStringAdmin() {
        return "Bonificacion \nempleado = " + empleado + ", id bono = " + id + ", descripcion = " + descripcion + ", valor = " + valor;
    }
    
    public String toStringProf(){
        return "Bonificacion \nempleado = " + empleado + ", id bono = " + id + ", descripcion = " + descripcion;
    }
}
