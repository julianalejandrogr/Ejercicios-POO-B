/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author USER
 */
public abstract class Empleado {
    protected String id;
    protected String nombre;
    protected String direccion;
    protected String correo;
    protected double salarioBase;
    protected Fecha fechaVinc;
    protected String cargo;

    public Empleado() {
    }

    public Empleado(String id, String nombre, String direccion, String correo, double salarioBase, Fecha fechaVinc, String cargo) {
        this.id = id;
        this.nombre = nombre;
        this.direccion = direccion;
        this.correo = correo;
        this.salarioBase = salarioBase;
        this.fechaVinc = fechaVinc;
        this.cargo = cargo;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }

    public Fecha getFechaVinc() {
        return fechaVinc;
    }

    public void setFechaVinc(Fecha fechaVinc) {
        this.fechaVinc = fechaVinc;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
}
