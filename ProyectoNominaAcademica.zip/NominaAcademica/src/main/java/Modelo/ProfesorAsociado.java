/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author USER
 */
public class ProfesorAsociado extends Profesor {
    private String categoriaAcademica;

    public ProfesorAsociado() {
    }

    public ProfesorAsociado(String categoriaAcademica, String especialidad, Asignatura asignatura, String tipoProfesor, Proyecto proyecto, Producto producto, String id, String nombre, String direccion, String correo, double salarioBase, Fecha fechaVinc, String cargo) {
        super(especialidad, asignatura, tipoProfesor, proyecto, producto, id, nombre, direccion, correo, salarioBase, fechaVinc, cargo);
        this.categoriaAcademica = categoriaAcademica;
    }

    public String getCategoriaAcademica() {
        return categoriaAcademica;
    }

    public void setCategoriaAcademica(String categoriaAcademica) {
        this.categoriaAcademica = categoriaAcademica;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public Asignatura getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(Asignatura asignatura) {
        this.asignatura = asignatura;
    }

    public String getTipoProfesor() {
        return tipoProfesor;
    }

    public void setTipoProfesor(String tipoProfesor) {
        this.tipoProfesor = tipoProfesor;
    }

    public Proyecto getProyecto() {
        return proyecto;
    }

    public void setProyecto(Proyecto proyecto) {
        this.proyecto = proyecto;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }

    public Fecha getFechaVinc() {
        return fechaVinc;
    }

    public void setFechaVinc(Fecha fechaVinc) {
        this.fechaVinc = fechaVinc;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    @Override
    public String toString() {
        return "ProfesorAsociado{" + "categoriaAcademica=" + categoriaAcademica + '}';
    }
    
}
