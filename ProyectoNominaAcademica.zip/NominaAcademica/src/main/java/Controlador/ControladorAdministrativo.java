package Controlador;

import Modelo.Administrativo;
import Modelo.Dependencia;
import Modelo.Fecha;
import Vista.JFAdministrativo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Double.parseDouble;
import static java.lang.Integer.parseInt;
import java.util.ArrayList;

/**
 *
 * @author fabian
 */
public class ControladorAdministrativo implements ActionListener{
    private JFAdministrativo frmAdministrativo;
    private ArrayList<Administrativo> listaAdministrativo;
    private ArrayList<Dependencia> listaDependencia;

    public ControladorAdministrativo(JFAdministrativo frmAdministrativo, ArrayList<Administrativo> listaAdministrativo, ArrayList<Dependencia> listaDependencia) {
        this.frmAdministrativo = frmAdministrativo;
        this.listaAdministrativo = listaAdministrativo;
        this.listaDependencia = listaDependencia;
        this.frmAdministrativo.btnRegistrar.addActionListener(this);
        this.frmAdministrativo.btnMostrar.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == frmAdministrativo.btnRegistrar){
            registrarAdministrativo();
        }
        if(e.getSource() == frmAdministrativo.btnMostrar){
            mostrarAdministrativo();
        }
    }
    
    public void registrarAdministrativo(){
        String id = frmAdministrativo.txtId.getText();
        String nombre = frmAdministrativo.txtCorreo.getText();
        String direccion = frmAdministrativo.txtNombre.getText();
        String correo = frmAdministrativo.txtDireccion.getText();
        double salarioBase = parseDouble(frmAdministrativo.txtSalario.getText());
        String fe = frmAdministrativo.txtFecha.getText();
        String[] fechas = fe.split("/");
        int dia = 0;
        int mes = 0;
        int año = 0;
        for(int i = 0; i<fechas.length; i++){
            if(i == 0){
                dia = parseInt(fechas[i]);
            }
            if(i == 1){
                mes = parseInt(fechas[i]);
            }
            if(i == 2){
                año = parseInt(fechas[i]);
            }
        }
        Fecha fechaVinculacion = new Fecha(dia, mes, año);
        String cargo = frmAdministrativo.txtCargo.getText();
        String dependencia = frmAdministrativo.txtDepencia.getText();
        String codigo = frmAdministrativo.txtCodigo.getText();
        Dependencia de = new Dependencia();
        for(Dependencia d : listaDependencia){
            de = d;
        }
        if(id.isEmpty() || nombre.isEmpty() || direccion.isEmpty() || correo.isEmpty() || frmAdministrativo.txtSalario.getText().isEmpty() || fe.isEmpty() || cargo.isEmpty() || codigo.isEmpty() || dependencia.isEmpty()){
            frmAdministrativo.areaResultados.setText("Rellene todos los campos");
            return;
        }
        if(buscarAdministrativo() == true){
            frmAdministrativo.areaResultados.setText("Ya existe este administrativo");
            return;
        }
        Administrativo ad = new Administrativo(de, codigo, id, nombre, direccion, correo, salarioBase, fechaVinculacion, cargo);
    }
    public void mostrarAdministrativo(){
        for(Administrativo a : listaAdministrativo){
            frmAdministrativo.areaResultados.append(a.toString() + "\n");
        }
    }
    
    public boolean buscarAdministrativo(){
        for(Administrativo a : listaAdministrativo){
            if(a.getId().equalsIgnoreCase(frmAdministrativo.txtId.getText())){
                return true;
            }
        }
        return false;
    }
}
