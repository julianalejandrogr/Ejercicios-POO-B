package Controlador;

import Modelo.Administrativo;
import Modelo.Bonificacion;
import Modelo.Profesor;
import Modelo.ProfesorCatedratico;
import Modelo.ProfesorOcasional;
import Vista.JFEmpleado;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 *
 * @author fabian
 */
public class ControladorNomina implements ActionListener{
    private JFEmpleado frmEmpleado;
    private ArrayList<Bonificacion> listaBonificacion;
    private ArrayList<Profesor> listaProfesor;
    private ArrayList<Administrativo> listaAdministrativo;

    public ControladorNomina(JFEmpleado frmEmpleado, ArrayList<Bonificacion> listaBonificacion, ArrayList<Profesor> listaProfesor, ArrayList<Administrativo> listaAdministrativo) {
        this.frmEmpleado = frmEmpleado;
        this.listaBonificacion = listaBonificacion;
        this.listaProfesor = listaProfesor;
        this.listaAdministrativo = listaAdministrativo;
        this.frmEmpleado.btnCalcular.addActionListener(this);
        this.frmEmpleado.btnBuscar.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == frmEmpleado.btnCalcular){
            calcularNomina();
        }
        if(e.getSource() == frmEmpleado.btnBuscar){
            buscarEmpleado();
        }
    }
    
    public void calcularNomina(){
        frmEmpleado.areaResultados.setText("");
        String id = frmEmpleado.txtId.getText();
        for(Profesor p : listaProfesor){
            if(p.getId().equalsIgnoreCase(frmEmpleado.txtId.getText())){
                double multiplicador = 0;
                p.getSalarioBase();
                if(p.getProducto().getPuntos() <= 20){
                    multiplicador = 0.05;
                }
                if(p.getProducto().getPuntos() >=21 && p.getProducto().getPuntos() <= 40){
                    multiplicador = 0.1;
                }
                if(p.getProducto().getPuntos() >=41){
                    multiplicador = 0.15;
                }
                if(p.getTipoProfesor().equalsIgnoreCase("Asociado")){
                    double nom = p.getSalarioBase() + (p.getSalarioBase() * multiplicador);
                    frmEmpleado.areaResultados.setText("La nomina del empleado con id " + id + " es de = " + nom );
                    return;
                }
                if(p.getTipoProfesor().equalsIgnoreCase("Catedratico")){
                    ProfesorCatedratico pc = new ProfesorCatedratico();
                    pc = (ProfesorCatedratico) p;
                    double nom = pc.getHoras() * pc.getValorHoras();
                    nom = nom * multiplicador;
                    frmEmpleado.areaResultados.setText("La nomina del empleado con id " + id + " es de = " + nom );
                    return;
                }
                if(p.getTipoProfesor().equalsIgnoreCase("Ocasional")){
                    ProfesorOcasional po = new ProfesorOcasional();
                    po = (ProfesorOcasional) p;
                    double nom = po.getSalarioBase() + (po.getSalarioBase() * multiplicador);
                    frmEmpleado.areaResultados.setText("La nomina del empleado con id " + id + " es de = " + nom );
                    return;
                }
            }
        }
        for(Administrativo a : listaAdministrativo){
            if(a.getId().equalsIgnoreCase(id)){
                double nom = a.getSalarioBase();
                for(Bonificacion b : listaBonificacion){
                    if(b.getEmpleado().equals(a)){
                        nom = a.getSalarioBase() + b.getValor();
                        frmEmpleado.areaResultados.setText("La nomina del empleado con id " + id + " es de = " + nom );
                        return;
                    }
                }
                frmEmpleado.areaResultados.setText("La nomina del empleado con id " + id + " es de = " + nom );
                return;
            }
        }
        frmEmpleado.areaResultados.setText("No existe un empleado con ese id");
    }
    
    public void buscarEmpleado(){
        frmEmpleado.areaResultados.setText("");
        for(Profesor p : listaProfesor){
            if(p.getId().equalsIgnoreCase(frmEmpleado.txtId.getText())){
                frmEmpleado.areaResultados.setText(p.toString());
                return;
            }
        }
        for(Administrativo a : listaAdministrativo){
            if(a.getId().equalsIgnoreCase(frmEmpleado.txtId.getText())){
                frmEmpleado.areaResultados.setText(a.toString());
                return;
            }
        }
    }
    
}
