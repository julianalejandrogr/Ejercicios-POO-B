package Controlador;
import Vista.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author fabian
 */
public class ControladorPrincipal implements ActionListener{
    private JFPrincipal frmPrincipal;
    private JFAdministrativo frmAdministrativo;
    private JFAsignatura frmAsignatura;
    private JFBono frmBono;
    private JFDependencia frmDependencia;
    private JFEmpleado frmEmpleado;
    private JFProfesor frmProfesor;
    private JFProyecto frmProyecto;

    public ControladorPrincipal(JFPrincipal frmPrincipal, JFAdministrativo frmAdministrativo, JFAsignatura frmAsignatura, JFBono frmBono, JFDependencia frmDependencia, JFEmpleado frmEmpleado, JFProfesor frmProfesor, JFProyecto frmProyecto) {
        this.frmPrincipal = frmPrincipal;
        this.frmAdministrativo = frmAdministrativo;
        this.frmAsignatura = frmAsignatura;
        this.frmBono = frmBono;
        this.frmDependencia = frmDependencia;
        this.frmEmpleado = frmEmpleado;
        this.frmProfesor = frmProfesor;
        this.frmProyecto = frmProyecto;
        this.frmPrincipal.btnAdministrativo.addActionListener(this);
        this.frmPrincipal.btnAsignatura.addActionListener(this);
        this.frmPrincipal.btnBonificacion.addActionListener(this);
        this.frmPrincipal.btnCalcular.addActionListener(this);
        this.frmPrincipal.btnDependencia.addActionListener(this);
        this.frmPrincipal.btnProfesor.addActionListener(this);
        this.frmPrincipal.btnProyecto.addActionListener(this);
        this.frmAdministrativo.setVisible(false);
        this.frmAsignatura.setVisible(false);
        this.frmBono.setVisible(false);
        this.frmDependencia.setVisible(false);
        this.frmEmpleado.setVisible(false);
        this.frmProfesor.setVisible(false);
        this.frmProyecto.setVisible(false);
    }
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == frmPrincipal.btnAdministrativo){
            administrativo();
        }
        if(e.getSource() == frmPrincipal.btnAsignatura){
            asignatura();
        }
        if(e.getSource() == frmPrincipal.btnBonificacion){
            bonificacion();
        }
        if(e.getSource() == frmPrincipal.btnCalcular){
            calcular();
        }
        if(e.getSource() == frmPrincipal.btnDependencia){
            dependencia();
        }
        if(e.getSource() == frmPrincipal.btnProfesor){
            profesor();
        }
        if(e.getSource() == frmPrincipal.btnProyecto){
            proyecto();
        }
    }
    
    public void administrativo(){
        frmAdministrativo.setVisible(true);
    }
    
    public void asignatura(){
        frmAsignatura.setVisible(true);
    }
    public void bonificacion(){
        frmBono.setVisible(true);
    }
    public void calcular(){
        frmEmpleado.setVisible(true);
    }
    public void dependencia(){
        frmDependencia.setVisible(true);
    }
    public void profesor(){
        frmProfesor.setVisible(true);
    }
    public void proyecto(){
        frmProyecto.setVisible(true);
    }

}
