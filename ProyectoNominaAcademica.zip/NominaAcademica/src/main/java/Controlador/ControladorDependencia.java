package Controlador;

import Modelo.Dependencia;
import Vista.JFDependencia;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 *
 * @author fabian
 */
public class ControladorDependencia implements ActionListener{
    private JFDependencia frmDependencia;
    private ArrayList<Dependencia> listaDependencia;

    public ControladorDependencia(JFDependencia frmDependencia, ArrayList<Dependencia> listaDependencia) {
        this.frmDependencia = frmDependencia;
        this.listaDependencia = listaDependencia;
        this.frmDependencia.btnRegistrar.addActionListener(this);
        this.frmDependencia.btnMostrar.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == frmDependencia.btnRegistrar){
            registrarDependencia();
        }
        if(e.getSource() == frmDependencia.btnMostrar){
            mostrarDependencia();
        }
    }
    
    public void registrarDependencia(){
        frmDependencia.areaResultados.setText("");
        String codigo = frmDependencia.txtCodigo.getText();
        String nombre = frmDependencia.txtNombre.getText();
        if(codigo.isEmpty() || nombre.isEmpty()){
            frmDependencia.areaResultados.setText("Todos los campos son obligatorios");
            return;
        }
        if(buscarDependencia() == true){
            frmDependencia.areaResultados.setText("Ya existe esa dependencia");
            return;
        }
        Dependencia d = new Dependencia(codigo, nombre);
        listaDependencia.add(d);
        frmDependencia.areaResultados.setText("Se registro la dependencia");
    }
    
    public void mostrarDependencia(){
        frmDependencia.areaResultados.setText("");
        for(Dependencia d : listaDependencia){
            frmDependencia.areaResultados.append(d.toString() + "\n");
        }
    }
    
    public boolean buscarDependencia(){
        for(Dependencia d : listaDependencia){
            if(d.getCodigo().equalsIgnoreCase(frmDependencia.txtCodigo.getText())){
                return true;
            }
        }
        return false;
    }
}
