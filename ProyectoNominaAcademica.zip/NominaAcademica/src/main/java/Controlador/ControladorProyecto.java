package Controlador;
import Vista.JFProyecto;
import Modelo.Proyecto;
import Modelo.Producto;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Integer.parseInt;
import java.util.ArrayList;
/**
 *
 * @author fabian
 */
public class ControladorProyecto implements ActionListener{
    private JFProyecto frmProyecto;
    private ArrayList<Producto> listaProductos;
    private ArrayList<Proyecto> listaProyectos;

    public ControladorProyecto(JFProyecto frmProyecto, ArrayList<Proyecto> listaProyectos, ArrayList<Producto> listaProductos) {
        this.frmProyecto = frmProyecto;
        this.listaProyectos = listaProyectos;
        this.listaProductos = listaProductos;
        this.frmProyecto.btnRegistrar.addActionListener(this);
        this.frmProyecto.btnMostrar.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == frmProyecto.btnRegistrar){
            registrarProyecto();
        }
        if(e.getSource() == frmProyecto.btnMostrar){
            mostrarProyecto();
        }
    }
    
    public void registrarProyecto(){
        frmProyecto.AreaResultados.setText("");
        String nombre = frmProyecto.txtNombre.getText();
        String tipo = frmProyecto.boxTipo.getSelectedItem().toString();
        String tipoProducto = frmProyecto.boxTipoProducto.getSelectedItem().toString();
        int puntos = parseInt(frmProyecto.txtPuntos.getText());
        
        if(nombre.isEmpty() || tipo.isEmpty() || tipoProducto.isEmpty() || frmProyecto.txtPuntos.getText().isEmpty()){
            frmProyecto.AreaResultados.setText("Todos los campos son obligatorios");
            return;
        }
        if(buscarProyectos() == true){
            frmProyecto.AreaResultados.setText("Ya existe este proyecto");
            return;
        }
        Producto pr = new Producto(tipo, puntos);
        listaProductos.add(pr);
        Proyecto p = new Proyecto(nombre, tipo, pr);
        listaProyectos.add(p);
        frmProyecto.AreaResultados.setText("Se ha registrado el proyecto correctamente");
    }
    
    public void mostrarProyecto(){
        frmProyecto.AreaResultados.setText("");
        for(Proyecto p : listaProyectos){
            frmProyecto.AreaResultados.append(p.toString() + "\n");
        }
    }
    
    public boolean buscarProyectos(){
        for(Proyecto p : listaProyectos){
            if(p.getNombre().equalsIgnoreCase(frmProyecto.txtNombre.getText())){
                return true;
            }
        }
        return false;
    }
}
