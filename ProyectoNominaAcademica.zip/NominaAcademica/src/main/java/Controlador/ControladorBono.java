package Controlador;

import Modelo.Administrativo;
import Modelo.Bonificacion;
import Modelo.Profesor;
import Vista.JFBono;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Double.parseDouble;
import java.util.ArrayList;

/**
 *
 * @author fabian
 */
public class ControladorBono implements ActionListener{
    private JFBono frmBono;
    private ArrayList<Profesor> listaProfesor;
    private ArrayList<Administrativo> listaAdministrativo;
    private ArrayList<Bonificacion> listaBonificacion;

    public ControladorBono(JFBono frmBono, ArrayList<Profesor> listaProfesor, ArrayList<Administrativo> listaAdministrativo, ArrayList<Bonificacion> listaBonificacion) {
        this.frmBono = frmBono;
        this.listaProfesor = listaProfesor;
        this.listaAdministrativo = listaAdministrativo;
        this.listaBonificacion = listaBonificacion;
        this.frmBono.btnRegistrar.addActionListener(this);
        this.frmBono.btnQuitar.addActionListener(this);
    }
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == frmBono.btnRegistrar){
            registrarBonificacion();
        }
        if(e.getSource() == frmBono.btnQuitar){
            quitarBonificacion();
        }
    }
    
    public void registrarBonificacion(){
        frmBono.areaResultados.setText("");
        String idEmpleado = frmBono.txtIdEmpleado.getText();
        String idBono = frmBono.txtIdBono.getText();
        String descripcion = frmBono.txtDescripcion.getText();
        if(idEmpleado.isEmpty() || idBono.isEmpty() || descripcion.isEmpty()){
            frmBono.areaResultados.setText("Rellene los campos de id empleado, id bono y descripcion");
            return;
        }
        if(buscarBonificacion() == true){
            frmBono.areaResultados.setText("Esta bonificacion ya existe");
            return;
        }
        for(Profesor p : listaProfesor){
            if(p.getId().equalsIgnoreCase(idEmpleado)){
                Bonificacion b = new Bonificacion(p, idBono, descripcion);
                listaBonificacion.add(b);
                frmBono.areaResultados.setText("Se ha registrado la bonificacion correctamente");
                return;
            }
        }
        Administrativo a = new Administrativo();
        for(Administrativo ad : listaAdministrativo){
            if(ad.getId().equalsIgnoreCase(idEmpleado)){
                a = ad;
            }
        }
        Double valor = parseDouble(frmBono.txtValor.getText());
        Bonificacion b = new Bonificacion(a, idBono, descripcion, valor);
        listaBonificacion.add(b);
        frmBono.areaResultados.setText("Se ha registrado la bonificacion correctamente");
    }
    
    public void quitarBonificacion(){
        frmBono.areaResultados.setText("");
        String idBono = frmBono.txtIdBono.getText();
        if(buscarBonificacion() == false){
            frmBono.areaResultados.setText("No se ha encontrado esa bonificacion");
            return;
        }
        for(Bonificacion b : listaBonificacion){
            if(b.getId().equalsIgnoreCase(frmBono.txtIdBono.getText())){
                listaBonificacion.remove(b);
                frmBono.areaResultados.setText("Se ha removido esa bonificacion");
                return;
            }
        }
    }
    
    public Boolean buscarBonificacion(){
        for(Bonificacion b : listaBonificacion){
            if(b.getId().equalsIgnoreCase(frmBono.txtIdBono.getText())){
                return true;
            }
        }
        return false;
    }
}
