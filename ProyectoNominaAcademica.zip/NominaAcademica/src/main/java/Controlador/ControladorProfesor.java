package Controlador;
import Modelo.Asignatura;
import Modelo.Fecha;
import Modelo.Producto;
import Modelo.Profesor;
import Modelo.ProfesorAsociado;
import Modelo.ProfesorCatedratico;
import Modelo.ProfesorOcasional;
import Modelo.Proyecto;
import Vista.JFProfesor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Double.parseDouble;
import static java.lang.Integer.parseInt;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
/**
 *
 * @author fabian
 */
public class ControladorProfesor implements ActionListener{
    private JFProfesor frmProfesor;
    private ArrayList<Profesor> listaProfesor;
    private ArrayList<Proyecto> listaProyecto;
    private ArrayList<Asignatura> listaAsignatura;
    private ArrayList<Producto> listaProducto;
    
    public ControladorProfesor(JFProfesor frmProfesor, ArrayList<Profesor> listaProfesor, ArrayList<Proyecto> listaProyectos, ArrayList<Asignatura> listaAsig, ArrayList<Producto> listaProductos) {
        this.frmProfesor = frmProfesor;
        this.listaProfesor = listaProfesor;
        this.listaProyecto = listaProyectos;
        this.listaProducto = listaProductos;
        this.listaAsignatura = listaAsig;
        this.frmProfesor.btnRegistrar.addActionListener(this);
        this.frmProfesor.btnMostrar.addActionListener(this);
        this.frmProfesor.boxTipoProfesor.addActionListener(this);
        this.frmProfesor.txtCategoria.setEnabled(false);
        this.frmProfesor.txtHoras.setEnabled(false);
        this.frmProfesor.txtValorHora.setEnabled(false);
        this.frmProfesor.txtMeses.setEnabled(false);
        this.frmProfesor.txtModalidad.setEnabled(false);
        this.frmProfesor.txtSalarioMes.setEnabled(false);
        cargarAsignaturas();
    }
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == frmProfesor.btnRegistrar){
            registrarProfesor();
        }
        if(e.getSource() == frmProfesor.btnMostrar){
            mostrarProfesor();
        }
        if(e.getSource() == frmProfesor.boxTipoProfesor){
            cambiarEspecifico();
        }
    }
    
    public void registrarProfesor(){
        frmProfesor.areaResultados.setText("");
        String id = frmProfesor.txtId.getText();
        String nombre = frmProfesor.txtCorreo.getText();
        String direccion = frmProfesor.txtNombre.getText();
        String correo = frmProfesor.txtDireccion.getText();
        double salarioBase = parseDouble(frmProfesor.txtSalarioBase.getText());
        String fe = frmProfesor.txtFechaVinculacion.getText();
        String[] fechas = fe.split("/");
        int dia = 0;
        int mes = 0;
        int año = 0;
        for(int i = 0; i<fechas.length; i++){
            if(i == 0){
                dia = parseInt(fechas[i]);
            }
            if(i == 1){
                mes = parseInt(fechas[i]);
            }
            if(i == 2){
                año = parseInt(fechas[i]);
            }
        }
        Fecha fechaVinculacion = new Fecha(dia, mes, año);
        String cargo = frmProfesor.txtCargo.getText();
        String especialidad = frmProfesor.txtEspecialidad.getText();
        String asignatura = frmProfesor.boxAsignatura.getSelectedItem().toString();
        String tipo = frmProfesor.boxTipoProfesor.getSelectedItem().toString();
        String proyecto = frmProfesor.txtProyecto.getText();
        Proyecto po = new Proyecto();
        for(Proyecto p : listaProyecto){
            if(p.getNombre().equalsIgnoreCase(proyecto)){
                po = p;
            }
        }
        String producto = frmProfesor.txtProducto.getText();
        Producto pr = new Producto();
        for(Producto pro : listaProducto){
            if(pro.getTipo().equalsIgnoreCase(producto)){
                pr = pro;
            }
        }
        if(id.isEmpty() || nombre.isEmpty() || direccion.isEmpty() || correo.isEmpty() || frmProfesor.txtSalarioBase.getText().isEmpty() || fe.isEmpty() || cargo.isEmpty() || especialidad.isEmpty() || asignatura.isEmpty()){
            frmProfesor.areaResultados.setText("Rellene todos los campos");
            return;
        }
        Asignatura ass = new Asignatura();
        for(Asignatura a : listaAsignatura){
            if(a.getNombre().equalsIgnoreCase(frmProfesor.boxAsignatura.getSelectedItem().toString())){
                ass = a;
            }
        }
        if(buscarProfesor() == true){
            frmProfesor.areaResultados.setText("Ya existe ese profesor");
            return;
        }
        if(frmProfesor.boxTipoProfesor.getSelectedItem().toString().equalsIgnoreCase("Asociado")){
            String categoria = frmProfesor.txtCategoria.getText();
            if(categoria.isEmpty()){
                frmProfesor.areaResultados.setText("Rellene todos los campos");
                return;
            }
            ProfesorAsociado pa = new ProfesorAsociado(categoria, especialidad, ass, tipo, po, pr, id, nombre, direccion, correo, salarioBase, fechaVinculacion, cargo);
            listaProfesor.add(pa);
            frmProfesor.areaResultados.setText("Se ha registrado al profesor");
            return;
        }
        if(frmProfesor.boxTipoProfesor.getSelectedItem().toString().equalsIgnoreCase("Catedratico")){
            int horas = parseInt(frmProfesor.txtHoras.getText());
            double valorHora = parseDouble(frmProfesor.txtValorHora.getText());
            if(frmProfesor.txtHoras.getText().isEmpty() || frmProfesor.txtValorHora.getText().isEmpty()){
                frmProfesor.areaResultados.setText("Rellene todos los campos");
                return;
            }
            ProfesorCatedratico pc = new ProfesorCatedratico(horas, valorHora, especialidad, ass, tipo, po, pr, id, nombre, direccion, correo, salarioBase, fechaVinculacion, cargo);
            listaProfesor.add(pc);
            frmProfesor.areaResultados.setText("Se ha registrado al profesor");
            return;
        }
        if(frmProfesor.boxTipoProfesor.getSelectedItem().toString().equalsIgnoreCase("Ocasional")){
            int meses = parseInt(frmProfesor.txtMeses.getText());
            double salarioMes = parseDouble(frmProfesor.txtSalarioMes.getText());
            String modalidad = frmProfesor.txtModalidad.getText();
            if(frmProfesor.txtMeses.getText().isEmpty() || frmProfesor.txtSalarioMes.getText().isEmpty() || modalidad.isEmpty()){
                frmProfesor.areaResultados.setText("Rellene todos los campos");
                return;
            }
            ProfesorOcasional prOcasional = new ProfesorOcasional(meses, modalidad, salarioMes, especialidad, ass, tipo, po, pr, id, nombre, direccion, correo, salarioBase, fechaVinculacion, cargo);
            listaProfesor.add(prOcasional);
            frmProfesor.areaResultados.setText("Se ha registrado al profesor");
        }
    }
    
    public void mostrarProfesor(){
        frmProfesor.areaResultados.setText("");
        for(Profesor p : listaProfesor){
            frmProfesor.areaResultados.append(p.toString() + "\n");
        }
    }
    
    public void cambiarEspecifico(){
        if(frmProfesor.boxTipoProfesor.getSelectedItem().toString().equalsIgnoreCase("Asociado")){
            frmProfesor.txtCategoria.setEnabled(true);
            frmProfesor.txtHoras.setEnabled(false);
            frmProfesor.txtValorHora.setEnabled(false);
            frmProfesor.txtMeses.setEnabled(false);
            frmProfesor.txtModalidad.setEnabled(false);
            frmProfesor.txtSalarioMes.setEnabled(false);
        }
        if(frmProfesor.boxTipoProfesor.getSelectedItem().toString().equalsIgnoreCase("Catedratico")){
            frmProfesor.txtCategoria.setEnabled(false);
            frmProfesor.txtHoras.setEnabled(true);
            frmProfesor.txtValorHora.setEnabled(true);
            frmProfesor.txtMeses.setEnabled(false);
            frmProfesor.txtModalidad.setEnabled(false);
            frmProfesor.txtSalarioMes.setEnabled(false);
        }
        if(frmProfesor.boxTipoProfesor.getSelectedItem().toString().equalsIgnoreCase("Ocasional")){
            frmProfesor.txtCategoria.setEnabled(false);
            frmProfesor.txtHoras.setEnabled(false);
            frmProfesor.txtValorHora.setEnabled(false);
            frmProfesor.txtMeses.setEnabled(true);
            frmProfesor.txtModalidad.setEnabled(true);
            frmProfesor.txtSalarioMes.setEnabled(true);
        }
    }
    
    private void cargarAsignaturas() {
    
        DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();

        for (Asignatura a : listaAsignatura) {
            modelo.addElement(a.getNombre());
        }

        frmProfesor.boxAsignatura.setModel(modelo);
    }
    
    public boolean buscarProfesor(){
        for(Profesor p : listaProfesor){
            if(p.getId().equalsIgnoreCase(frmProfesor.txtId.getText())){
                return true;
            }
        }
        return false;
    }
    
    public void actualizarAsignaturas(){
        cargarAsignaturas();
    }
}
