package Controlador;
import Modelo.Asignatura;
import Vista.JFAsignatura;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Integer.parseInt;
import java.util.ArrayList;

/**
 *
 * @author fabian
 */
public class ControladorAsignatura implements ActionListener{
    private JFAsignatura frmAsignatura;
    private ControladorProfesor ctrlProfesor;
    private ArrayList<Asignatura> listaAsignaturas;

    public ControladorAsignatura(JFAsignatura frmAsignatura, ArrayList<Asignatura> listaAsig, ControladorProfesor ctrlProfesor) {
        this.frmAsignatura = frmAsignatura;
        this.listaAsignaturas = listaAsig;
        this.ctrlProfesor = ctrlProfesor;
        this.frmAsignatura.btnRegistro.addActionListener(this);
        this.frmAsignatura.btnMostrar.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == frmAsignatura.btnRegistro){
            registrarAsignatura();
        }
        if(e.getSource() == frmAsignatura.btnMostrar){
            mostrarAsignatura();
        }
    }
    
    public void registrarAsignatura(){
        String nombre = frmAsignatura.txtNombre.getText();
        String codigo = frmAsignatura.txtCodigo.getText();
        int credito = parseInt(frmAsignatura.txtCreditos.getText());
        if(nombre.isEmpty() || codigo.isEmpty() || frmAsignatura.txtCreditos.getText().isEmpty()){
            frmAsignatura.areaResultados.setText("Todos los campos son obligatorios");
            return;
        }
        if(buscarAsignatura() == true){
            frmAsignatura.areaResultados.setText("Ya existe esa asignatura");
            return;
        }
        Asignatura a = new Asignatura(nombre, codigo, credito);
        listaAsignaturas.add(a);
        ctrlProfesor.actualizarAsignaturas();
        frmAsignatura.areaResultados.setText("Se ha registrado la asignatura");
    }
    
    public void mostrarAsignatura(){
        frmAsignatura.areaResultados.setText("");
        for(Asignatura a : listaAsignaturas){
            frmAsignatura.areaResultados.append(a.toString() + "\n");
        }
    }
    
    public boolean buscarAsignatura(){
        for(Asignatura a : listaAsignaturas){
            if(a.getCodigo().equalsIgnoreCase(frmAsignatura.txtCodigo.getText())){
                return true;
            }
        }
        return false;
    }
}
