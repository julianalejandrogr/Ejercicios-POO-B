package main;
import Controlador.ControladorAdministrativo;
import Controlador.ControladorAsignatura;
import Modelo.Empleado;
import Modelo.Asignatura;
import Modelo.Dependencia;
import Modelo.Proyecto;
import Modelo.Producto;
import Modelo.Profesor;
import Modelo.Administrativo;
import Modelo.Bonificacion;
import Controlador.ControladorProyecto;
import Controlador.ControladorProfesor;
import Controlador.ControladorBono;
import Controlador.ControladorNomina;
import Controlador.ControladorPrincipal;
import Vista.JFAdministrativo;
import Vista.JFAsignatura;
import Vista.JFDependencia;
import Vista.JFProfesor;
import Vista.JFProyecto;
import Vista.JFBono;
import Vista.JFEmpleado;
import Vista.JFPrincipal;
import java.util.ArrayList;

/**
 *
 * @author USER
 */
public class Main {

    public static void main(String[] args) {
        JFProyecto frmProyecto = new JFProyecto();
        JFAsignatura frmAsignatura = new JFAsignatura();
        JFProfesor frmProfesor = new JFProfesor();
        JFAdministrativo frmAdministrativo = new JFAdministrativo();
        JFDependencia frmDependencia = new JFDependencia();
        JFBono frmBono = new JFBono();
        JFEmpleado frmEmpleado = new JFEmpleado();
        JFPrincipal frmPrincipal = new JFPrincipal();
        ArrayList<Asignatura> listaAsig = new ArrayList<>();
        ArrayList<Empleado> listaEmpComp = new ArrayList<>();
        ArrayList<Dependencia> listaDep = new ArrayList<>();
        ArrayList<Proyecto> listaProyectos = new ArrayList<>();
        ArrayList<Producto> listaProductos = new ArrayList<>();
        ArrayList<Profesor> listaProfesor = new ArrayList<>();
        ArrayList<Administrativo> listaAdministrativo = new ArrayList<>();
        ArrayList<Dependencia> listaDependencia = new ArrayList<>();
        ArrayList<Bonificacion> listaBonificacion = new ArrayList<>();
        ControladorProyecto ctrlProyecto = new ControladorProyecto(frmProyecto, listaProyectos, listaProductos);
        ControladorProfesor ctrlProfesor = new ControladorProfesor(frmProfesor, listaProfesor, listaProyectos, listaAsig, listaProductos);
        ControladorAsignatura ctrlAsignatura = new ControladorAsignatura(frmAsignatura,listaAsig, ctrlProfesor);
        ControladorAdministrativo ctrlAdministrativo = new ControladorAdministrativo(frmAdministrativo, listaAdministrativo, listaDependencia);
        ControladorBono ctrlBonificacion = new ControladorBono(frmBono, listaProfesor, listaAdministrativo, listaBonificacion);
        ControladorNomina ctrlNomina = new ControladorNomina(frmEmpleado, listaBonificacion, listaProfesor, listaAdministrativo);
        ControladorPrincipal ctrlPrincipal = new ControladorPrincipal(frmPrincipal, frmAdministrativo, frmAsignatura, frmBono, frmDependencia, frmEmpleado, frmProfesor, frmProyecto);
        frmPrincipal.setVisible(true);
        frmBono.setVisible(false);
        frmAdministrativo.setVisible(false);
        frmAsignatura.setVisible(false);
        frmProyecto.setVisible(false);
        frmProfesor.setVisible(false);
        frmEmpleado.setVisible(false);
        frmDependencia.setVisible(false);
        /*ControladorEmpleado c = new ControladorEmpleado(frmEmpleadoo, listaDep, listaEmpComp, listaAsig);
        frmEmpleadoo.setVisible(false);
        frmEmpleadoo.pnAdmin.setVisible(false);
        frmEmpleadoo.pnProfesor.setVisible(false);
        frmEmpleadoo.lblCategoriaAcademica.setVisible(false);
        frmEmpleadoo.txtCategoria.setVisible(false);
        frmEmpleadoo.lblHoras.setVisible(false);
        frmEmpleadoo.txtHoras.setVisible(false);
        frmEmpleadoo.lblMeses.setVisible(false);
        frmEmpleadoo.txtMeses.setVisible(false);
        frmEmpleadoo.lblModalidad.setVisible(false);
        frmEmpleadoo.txtModalidad.setVisible(false);
        frmEmpleadoo.lblValor.setVisible(false);
        frmEmpleadoo.txtValorHora.setVisible(false);
        frmEmpleadoo.lblSalarioMes.setVisible(false);
        frmEmpleadoo.txtSalarioMes.setVisible(false);
        frmEmpleadoo.lblNomProy.setVisible(false);
        frmEmpleadoo.txtNomProy.setVisible(false);
        frmEmpleadoo.lblCodigoProy.setVisible(false);
        frmEmpleadoo.txtCodigoProy.setVisible(false);
        frmEmpleadoo.lblNomProd.setVisible(false);
        frmEmpleadoo.txtNomProd.setVisible(false);
        frmEmpleadoo.lblTipoProd.setVisible(false);
        frmEmpleadoo.cmbTipoProducto.setVisible(false);*/
    }
}
