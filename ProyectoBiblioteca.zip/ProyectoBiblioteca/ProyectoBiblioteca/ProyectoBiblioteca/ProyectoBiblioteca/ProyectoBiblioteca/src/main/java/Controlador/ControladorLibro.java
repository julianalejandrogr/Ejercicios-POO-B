package Controlador;

import Modelo.Libro;
import Modelo.LibroReferencia;
import Modelo.LibroGeneral;
import Modelo.Fecha;
import Vista.JFLibro;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Integer.parseInt;
import java.util.ArrayList;
/**
 *
 * @author crist
 */
public class ControladorLibro implements ActionListener{
    private JFLibro frmLibro;
    private ArrayList<Libro> listaLibros;
    private String resultado = "";
    private Fecha fechaPublicacion;
    
    public ArrayList<Libro> getListaLibros(){
    return listaLibros;
    }
    
    public ControladorLibro(JFLibro frmLibro){
        this.frmLibro = frmLibro;
        this.listaLibros = new ArrayList<>();
        this.frmLibro.btnGuardar.addActionListener(this);
        this.frmLibro.btnImprimir.addActionListener(this);
        this.frmLibro.btnLimpiar.addActionListener(this);
        
        System.out.println(frmLibro.btnGuardar);
 
    }
    
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == frmLibro.btnGuardar){
            guardarLibro();
        }
        if(e.getSource() == frmLibro.btnLimpiar){
            limpiarCampos();
        }
        if(e.getSource() == frmLibro.btnImprimir){
            imprimirResultados();
        }
    }
    
    private void guardarLibro(){
        String nombre = frmLibro.txtNombre.getText();
        String autor = frmLibro.txtAutor.getText();
        String issn = frmLibro.txtISSN.getText();
        String publicacion = frmLibro.txtFechaPublicacion.getText();
        String editorial = frmLibro.txtEditorial.getText();
        String tipoLibro = frmLibro.boxTipoLibro.getSelectedItem().toString();
        String copias = frmLibro.txtCopias.getText();
        int copia = 2;
        for(Libro l: listaLibros){
            if(l.getTitulo().equalsIgnoreCase(nombre)){
                this.frmLibro.areaResultados.setText("Este libro ya se encuentra registrado");
                return;
            }
        }
        if(tipoLibro.equalsIgnoreCase("Referencia")){
        if(nombre.isEmpty() || autor.isEmpty() || issn.isEmpty() || publicacion.isEmpty() || editorial.isEmpty()){
            this.frmLibro.areaResultados.setText("Todos los campos son obligatorios");
            return;
        }
        }
        else{
        if(nombre.isEmpty() || autor.isEmpty() || issn.isEmpty() || publicacion.isEmpty() || editorial.isEmpty() || copias.isEmpty()){
            this.frmLibro.areaResultados.setText("Todos los campos son obligatorios");
            return;
        }}
        String[] fechas = publicacion.split("/");
        int dia = 0;
        int mes = 0;    
        int año = 0;
        if(fechas.length != 3 || fechas[0].length() != 2 || fechas[1].length() != 2|| fechas[2].length() != 4){
            this.frmLibro.areaResultados.setText("La fecha debe tener formato dd/mm/aaaa");
            return;
}
        for(int i = 0; i<fechas.length; i++){
            if(i == 0){
                dia = parseInt(fechas[i]);
            }
            if(i == 1){
                mes = parseInt(fechas[i]);
            }
            if(i == 2){
                año = parseInt(fechas[i]);
            }
        }
        try{
            fechaPublicacion = new Fecha(dia, mes, año);
        }
        catch(IllegalArgumentException e){
            this.frmLibro.areaResultados.setText(e.getMessage());
            return;
        }
        if(tipoLibro.equalsIgnoreCase("Referencia")){
            Libro libroRef = new LibroReferencia(copia, nombre, autor, issn, fechaPublicacion, editorial);
        listaLibros.add(libroRef);
        }
        else{
        copia = Integer.parseInt(copias);
        if(copia <= 0){
            frmLibro.areaResultados.setText("La cantidad de copias registradas deben ser mayor que cero");
            return;
        }
        Libro libroGen = new LibroGeneral(copia, nombre, autor, issn, fechaPublicacion, editorial);
        listaLibros.add(libroGen);
        }
        
        
        this.frmLibro.areaResultados.setText("Libro guardado correctamente");
      
            System.out.println("=== DATOS DEL LIBRO ===");
                for(Libro l: listaLibros){
                System.out.println("Título: " + l.getTitulo());
                System.out.println("Autor: " + l.getAutor());
                System.out.println("ISSN: " + l.getIssn());
                System.out.println("Fecha de Publicación: " + l.getPublicacion()); 
                System.out.println("Tipo de Libro: " + l.getTipoLibro()); 
                System.out.println("Editorial: " + l.getEditorial());
                System.out.println("Cantidad de Copias: "+ l.getCopias()); 
                System.out.println("-------------------------");   
            }
                limpiarCampos();
            }

        public void limpiarCampos(){
          frmLibro.txtNombre.setText("");
          frmLibro.txtAutor.setText("");
          frmLibro.txtISSN.setText("");
          frmLibro.txtFechaPublicacion.setText("");
          frmLibro.txtEditorial.setText("");
          frmLibro.txtCopias.setText("");
          frmLibro.txtNombre.requestFocus();

        }

        public void imprimirResultados() {
        
            resultado = ""; 
            
        for (Libro l : listaLibros) {

            resultado +="\n=== DATOS DEL LIBRO ===" +"\nTítulo: "+ l.getTitulo() + "\nAutor: " + l.getAutor() + "\nISSN: " + l.getIssn()+"\nFecha de publicación: "+ l.getPublicacion()+ "\nEditorial:"+ l.getEditorial() +"\nTipo de libro: "+l.getTipoLibro()+"\nCantidad de copias: "+l.getCopias()+"\n--------------------------------";
        }
        this.frmLibro.areaResultados.setText(resultado);
        }
    
        public String entregarResultados(){
            
            return resultado;
        }
}
