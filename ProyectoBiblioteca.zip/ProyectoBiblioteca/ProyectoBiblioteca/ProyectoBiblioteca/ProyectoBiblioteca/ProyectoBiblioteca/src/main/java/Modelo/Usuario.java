/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author crist
 */
public abstract class Usuario {
    private String nombre; 
    private String apellido;
    private String tipoUsuario;
    private int codigo;
    private int cantidadLibros;
    private Libro titulo;

    public Usuario(String tipoUsuario, String nombre, String apellido, int codigo, int cantidadLibros, Libro titulo) {
        this.tipoUsuario = tipoUsuario;
        this.nombre = nombre;
        this.apellido = apellido;
        this.codigo = codigo;
        this.cantidadLibros = cantidadLibros;
        this.titulo = titulo;
    }
    
    
    public Usuario(){}
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getCantidadLibros() {
        return cantidadLibros;
    }

    public void setCantidadLibros(int cantidadLibros) {
        this.cantidadLibros = cantidadLibros;
    }

    public Libro getTitulo() {
        return titulo;
    }

    public void setTitulo(Libro titulo) {
        this.titulo = titulo;
    }

    public String getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(String tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }
    
    @Override
    public String toString() {
        return "Nombre del Usuario: " + nombre + "\nApellido del Usuario: " + apellido
           + "\nCódigo del Usuario: " + codigo +"\nTipo de Usuario: "+tipoUsuario+"\nTítulo del Libro seleccionado: "+titulo+ "\nCantidad de copias a prestar: "+cantidadLibros; 
    }
    public abstract int getPlazo();
}
