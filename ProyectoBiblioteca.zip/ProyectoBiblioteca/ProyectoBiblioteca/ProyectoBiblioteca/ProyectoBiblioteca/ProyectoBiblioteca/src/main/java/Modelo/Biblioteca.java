package Modelo;
/**
 *
 * @author crist
 */
public class Biblioteca {
    private Libro myLibro;
    private Prestamo myPrestamo;
    private Usuario myUsuario;

    public Biblioteca(Libro myLibro, Prestamo myPrestamo, Usuario myUsuario) {
        this.myLibro = myLibro;
        this.myPrestamo = myPrestamo;
        this.myUsuario = myUsuario;
    }

    public Libro getMyLibro() {
        return myLibro;
    }

    public void setMyLibro(Libro myLibro) {
        this.myLibro = myLibro;
    }

    public Prestamo getMyPrestamo() {
        return myPrestamo;
    }

    public void setMyPrestamo(Prestamo myPrestamo) {
        this.myPrestamo = myPrestamo;
    }

    public Usuario getMyUsuario() {
        return myUsuario;
    }

    public void setMyUsuario(Usuario myUsuario) {
        this.myUsuario = myUsuario;
    }
           
    
    
}
