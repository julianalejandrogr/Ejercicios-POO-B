/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Esstudiante
 */
public class Fecha {
    private int dia;
    private int mes;
    private int año;

    public Fecha(int dia, int mes, int año) {
        if(dia < 1 || dia > 31){
        throw new IllegalArgumentException("Dia invalido");
        }
        if(mes < 1 || mes > 12){
        throw new IllegalArgumentException("Mes invalido");
        }
        this.dia = dia;
        this.mes = mes;
        this.año = año;
    }
    public Fecha(){}

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }
    
    @Override
    public String toString() {
        return dia + "/" + mes + "/" + año;
    }
    
    public boolean calcularPosterioridad(Fecha fecha) {

    if(this.año > fecha.año){
        return true;
    }

    if(this.año == fecha.año && this.mes > fecha.mes){
        return true;
    }

    if(this.año == fecha.año &&
       this.mes == fecha.mes &&
       this.dia >= fecha.dia){
        return true;
    }

    return false;
    }
    public int calcularDias(Fecha fecha){
        return (año * 365 + mes * 30 + dia)
       -
       (fecha.año * 365 + fecha.mes * 30 + fecha.dia);
    }
}
