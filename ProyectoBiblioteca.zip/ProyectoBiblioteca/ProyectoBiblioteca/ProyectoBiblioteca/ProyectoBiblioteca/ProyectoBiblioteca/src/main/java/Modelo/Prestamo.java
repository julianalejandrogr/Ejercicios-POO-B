/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author crist
 */
public class Prestamo {
    private Usuario myUsuario;
    private Fecha fechaPrestamo;
    private Fecha fechaDevolucion;
    private EstadoPrestamo myEstadoPrestamo;

    public Prestamo(Usuario myUsuario, Fecha fechaPrestamo, EstadoPrestamo myEstadoPrestamo) {
        this.myUsuario = myUsuario;
        this.fechaPrestamo = fechaPrestamo;
        this.fechaDevolucion = fechaDevolucion;
        this.myEstadoPrestamo = myEstadoPrestamo;
    }
    
    public Prestamo(){}
    public Usuario getMyUsuario() {
        return myUsuario;
    }

    public void setMyUsuario(Usuario myUsuario) {
        this.myUsuario = myUsuario;
    }

    public Fecha getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(Fecha fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public Fecha getFechaDevolucion() {
        return fechaDevolucion;
    }

    public void setFechaDevolucion(Fecha fechaDevolucion) {
        this.fechaDevolucion = fechaDevolucion;
    }

    public EstadoPrestamo getMyEstadoPrestamo() {
        return myEstadoPrestamo;
    }

    public void setMyEstadoPrestamo(EstadoPrestamo myEstadoPrestamo) {
        this.myEstadoPrestamo = myEstadoPrestamo;
    }
    
    
}
