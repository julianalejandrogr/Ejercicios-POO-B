/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author crist
 */
public abstract class Libro {
    private String titulo;
    private String autor;
    private String issn;
    private Fecha publicacion;
    private String editorial;

    public Libro(String titulo, String autor, String issn, Fecha publicacion, String editorial) {
        this.titulo = titulo;
        this.autor = autor;
        this.issn = issn;
        this.publicacion = publicacion;
        this.editorial = editorial;
    }
    
    public Libro(){}
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getIssn() {
        return issn;
    }

    public void setIssn(String issn) {
        this.issn = issn;
    }

    public Fecha getPublicacion() {
        return publicacion;
    }

    public void setPublicacion(Fecha publicacion) {
        this.publicacion = publicacion;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }
    @Override
    public String toString() {
    return titulo;
    }
    
    public abstract int getCopias();
    public abstract void setCopias(int copias);
    public abstract String getTipoLibro();
}
