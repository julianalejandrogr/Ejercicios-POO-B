/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author crist
 */
public class LibroReferencia extends Libro{
    private int copias;

    public LibroReferencia(int copias, String titulo, String autor, String issn, Fecha publicacion, String editorial) {
        super(titulo, autor, issn, publicacion, editorial);
        this.copias = copias;
    }
    
    public LibroReferencia() {
    }
    
    @Override
    public int getCopias() {
        return copias;
    }

    @Override
    public void setCopias(int copias) {
        this.copias = copias;
    }
    
    @Override
    public String getTipoLibro() {
        return "REFERENCIA";
    }
    
    @Override
    public String toString() {
        return getTitulo();
    }
    
}
