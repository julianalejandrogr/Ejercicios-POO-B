/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Fecha;
import Modelo.Libro;
import Modelo.LibroGeneral;
import Modelo.LibroReferencia;
import Modelo.Prestamo;
import Modelo.EstadoPrestamo;
import Modelo.Estudiante;
import Modelo.Profesor;
import Modelo. Administrativo;
import Modelo.Usuario;
import Vista.JFPrestamo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Integer.parseInt;
import java.util.ArrayList;

/**
 *
 * @author crist
 */
public class ControladorPrestamo implements ActionListener{
    private JFPrestamo frmPrestamo;
    private ArrayList<Prestamo> listaPrestamos;
    public ArrayList<Prestamo> getListaPrestamos(){
    return listaPrestamos;
}
    private String resultado = "";
    private ControladorLibro controladorLibro;
    private Fecha fechaPrestamo;
    
    
    public ControladorPrestamo(JFPrestamo frmPrestamo, ControladorLibro controladorLibro){
        this.frmPrestamo = frmPrestamo;
        this.controladorLibro = controladorLibro;
        this.listaPrestamos = new ArrayList<>();
        
        this.frmPrestamo.btnGuardar.addActionListener(this);
        this.frmPrestamo.btnImprimir.addActionListener(this);
        this.frmPrestamo.btnLimpiar.addActionListener(this);
        this.frmPrestamo.btnCargarLibros.addActionListener(this);
        
        System.out.println(frmPrestamo.btnGuardar);
 
    }
    
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == frmPrestamo.btnCargarLibros){
            cargarLibros();
        }
        if(e.getSource() == frmPrestamo.btnGuardar){
            guardarLibro(); 
        }
        if(e.getSource() == frmPrestamo.btnLimpiar){
            limpiarCampos();
        }
        if(e.getSource() == frmPrestamo.btnImprimir){
            imprimirResultados();
        }
    }
    public void cargarLibros(){

    frmPrestamo.boxTitulo.removeAllItems();

    for(Libro l : controladorLibro.getListaLibros()){
        frmPrestamo.boxTitulo.addItem(l);
    }}
    private void guardarLibro(){
        String nombre = frmPrestamo.txtNombre.getText();
        String apellido = frmPrestamo.txtApellido.getText();
        String codigo = frmPrestamo.txtCodigo.getText();
        String tipoUsuario = frmPrestamo.boxTipoUsuario.getSelectedItem().toString();
        Libro libroSeleccionado = (Libro) frmPrestamo.boxTitulo.getSelectedItem();
        if(libroSeleccionado == null){
            this.frmPrestamo.areaResultados.setText(
                    "No hay libros disponibles"
        );
            return;
        }
        String cantidad = frmPrestamo.txtCantidadLibros.getText();
        String stringPrestamo = frmPrestamo.txtFechaPrestamo.getText();
        int plazo =0;
        if(nombre.isEmpty() || apellido.isEmpty() || codigo.isEmpty() || cantidad.isEmpty() || stringPrestamo.isEmpty()){
            this.frmPrestamo.areaResultados.setText("Todos los campos son obligatorios");
            return;
        }
        int intCodigo = Integer.parseInt(codigo);
        int intCantidad= Integer.parseInt(cantidad);
        if(intCantidad <= 0){
            frmPrestamo.areaResultados.setText("La cantidad de copias solicitadas deben ser mayor que cero");
            return;
        }
        String[] fechas = stringPrestamo.split("/");
        int dia = 0;
        int mes = 0;    
        int año = 0;
        if(fechas.length != 3 || fechas[0].length() != 2 || fechas[1].length() != 2|| fechas[2].length() != 4){
            this.frmPrestamo.areaResultados.setText("La fecha debe tener formato dd/mm/aaaa");
            return;
}
        for(int i = 0; i<fechas.length; i++){
            if(i == 0){
                dia = parseInt(fechas[i]);
            }
            if(i == 1){
                mes = parseInt(fechas[i]);
            }
            if(i == 2){
                año = parseInt(fechas[i]);
            }
        }
        try{
            fechaPrestamo = new Fecha(dia, mes, año);
        }
        catch(IllegalArgumentException e){
            this.frmPrestamo.areaResultados.setText(e.getMessage());
            return;
        }
        if(!fechaPrestamo.calcularPosterioridad(libroSeleccionado.getPublicacion())){
            this.frmPrestamo.areaResultados.setText(
                    "La fecha del préstamo debe ser posterior a la fecha de publicación"
            );
            return;
        }
        if(intCantidad > libroSeleccionado.getCopias()){
            this.frmPrestamo.areaResultados.setText(
                    "No hay suficientes copias disponibles"
            );
            return;
        }
        else{
            libroSeleccionado.setCopias(libroSeleccionado.getCopias() - intCantidad);
        }
        if(tipoUsuario.equalsIgnoreCase("Administrativo")){
            plazo = 3;
            EstadoPrestamo estadoPrestamo = EstadoPrestamo.valueOf("PRESTADO");
            Usuario admin = new Administrativo(tipoUsuario,plazo, nombre, apellido, intCodigo, intCantidad, libroSeleccionado);
            Prestamo prestamo = new Prestamo(admin, fechaPrestamo, estadoPrestamo);
        listaPrestamos.add(prestamo);
        }
        else if(tipoUsuario.equalsIgnoreCase("Profesor")){
            plazo = 15;
            EstadoPrestamo estadoPrestamo = EstadoPrestamo.valueOf("PRESTADO");
            Usuario profesor = new Profesor(tipoUsuario, plazo, nombre, apellido, intCodigo, intCantidad, libroSeleccionado);
            Prestamo prestamo = new Prestamo(profesor, fechaPrestamo, estadoPrestamo);
        listaPrestamos.add(prestamo);
        }
        else if(tipoUsuario.equalsIgnoreCase("Estudiante")){
            plazo = 15;
            EstadoPrestamo estadoPrestamo = EstadoPrestamo.valueOf("PRESTADO");
            Usuario estudiante = new Estudiante(tipoUsuario, plazo, nombre, apellido, intCodigo, intCantidad, libroSeleccionado);
            Prestamo prestamo = new Prestamo(estudiante, fechaPrestamo, estadoPrestamo);
        listaPrestamos.add(prestamo);
        }
        
        
        this.frmPrestamo.areaResultados.setText("Prestamo realizado correctamente");
      
            System.out.println("=== DATOS DEL PRESTAMO ===");
                for(Prestamo p: listaPrestamos){
                System.out.println(p.getMyUsuario());
                System.out.println("Fecha del Prestamo: "+ p.getFechaPrestamo()); 
                System.out.println("-------------------------");   
            }
                limpiarCampos();
            }

        public void limpiarCampos(){
          frmPrestamo.txtNombre.setText("");
          frmPrestamo.txtApellido.setText("");
          frmPrestamo.txtCodigo.setText("");
          frmPrestamo.txtCantidadLibros.setText("");
          frmPrestamo.txtFechaPrestamo.setText("");
          frmPrestamo.txtNombre.requestFocus();

        }

        public void imprimirResultados() {
        
            resultado = ""; 
            
        for (Prestamo p : listaPrestamos) {

            resultado +="\n=== DATOS DEL PRESTAMO ==="+"\n"+ p.getMyUsuario() + "\nFecha Prestamo: " + p.getFechaPrestamo()+"\n--------------------------------";
        }
        this.frmPrestamo.areaResultados.setText(resultado);
        }
    
        public String entregarResultados(){
            
            return resultado;
        }
}
