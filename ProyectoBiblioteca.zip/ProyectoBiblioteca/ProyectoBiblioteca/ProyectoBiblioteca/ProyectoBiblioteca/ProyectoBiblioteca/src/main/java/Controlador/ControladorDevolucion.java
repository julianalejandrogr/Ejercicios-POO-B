/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.EstadoPrestamo;
import Modelo.Fecha;
import Modelo.Libro;
import Modelo.Prestamo;
import Vista.JFDevolucion;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.Integer.parseInt;
/**
 *
 * @author crist
 */
public class ControladorDevolucion implements ActionListener {
    private JFDevolucion frmDevolucion;
    private String resultado = "";
    private int intCodigo;
    private int intCantidad;
    private int diasTranscurridos;
    
    private Libro libroSeleccionado;
    private Prestamo prestamo;
    private ControladorLibro controladorLibro;
    private ControladorPrestamo controladorPrestamo;
    private Fecha fechaDevolucion;
    
    
    public ControladorDevolucion(JFDevolucion frmDevolucion, ControladorLibro controladorLibro, ControladorPrestamo controladorPrestamo){
        this.frmDevolucion = frmDevolucion;
        this.controladorLibro = controladorLibro;
        this.controladorPrestamo = controladorPrestamo;
        
        this.frmDevolucion.btnGuardar.addActionListener(this);
        this.frmDevolucion.btnImprimir.addActionListener(this);
        this.frmDevolucion.btnLimpiar.addActionListener(this);
        this.frmDevolucion.btnCargarLibros.addActionListener(this);
        
        System.out.println(frmDevolucion.btnGuardar);
 
    }
    
    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == frmDevolucion.btnCargarLibros){
            cargarLibros();
        }
        if(e.getSource() == frmDevolucion.btnGuardar){
            guardarDevolucion(); 
        }
        if(e.getSource() == frmDevolucion.btnLimpiar){
            limpiarCampos();
        }
        if(e.getSource() == frmDevolucion.btnImprimir){
            imprimirResultados();
        }
    }
    public void cargarLibros(){

    frmDevolucion.boxTitulo.removeAllItems();

    for(Libro l : controladorLibro.getListaLibros()){
        frmDevolucion.boxTitulo.addItem(l);
    }}
    private Prestamo buscarPrestamo(int codigo, Libro libroSeleccionado){

    for(Prestamo p :
            controladorPrestamo.getListaPrestamos()){

        if(p.getMyUsuario().getCodigo() == codigo
                && p.getMyUsuario().getTitulo().equals(libroSeleccionado)){

            return p;
        }
    }
    return null;
    }
    private void guardarDevolucion(){
        String codigo = frmDevolucion.txtCodigo.getText();
        libroSeleccionado = (Libro) frmDevolucion.boxTitulo.getSelectedItem();
        if(libroSeleccionado == null){
            this.frmDevolucion.areaResultados.setText(
                    "No hay libros disponibles"
        );
            return;
        }
        String cantidad = frmDevolucion.txtCopias.getText();
        String stringDevolucion = frmDevolucion.txtFechaDevolucion.getText();
        if(codigo.isEmpty() || cantidad.isEmpty() || stringDevolucion.isEmpty()){
            this.frmDevolucion.areaResultados.setText("Todos los campos son obligatorios");
            return;
        }
        intCodigo = Integer.parseInt(codigo);
        intCantidad= Integer.parseInt(cantidad);
        if(intCantidad<= 0){
            frmDevolucion.areaResultados.setText("La cantidad de copias devueltas debe ser mayor que cero");
            return;
        }
        String[] fechas = stringDevolucion.split("/");
        int dia = 0;
        int mes = 0;    
        int año = 0;
        if(fechas.length != 3 || fechas[0].length() != 2 || fechas[1].length() != 2|| fechas[2].length() != 4){
            this.frmDevolucion.areaResultados.setText("La fecha debe tener formato dd/mm/aaaa");
            return;
        }
        for(int i = 0; i<fechas.length; i++){
            if(i == 0){
                dia = parseInt(fechas[i]);
            }
            if(i == 1){
                mes = parseInt(fechas[i]);
            }
            if(i == 2){
                año = parseInt(fechas[i]);
            }
        }
        try{
            fechaDevolucion = new Fecha(dia, mes, año);
        }
        catch(IllegalArgumentException e){
            this.frmDevolucion.areaResultados.setText(e.getMessage());
            return;
        }
        prestamo = buscarPrestamo(intCodigo, libroSeleccionado);
        
        if(prestamo == null){    
            frmDevolucion.areaResultados.setText("No existe un préstamo para ese usuario y libro");
            return;
        }
        if(!fechaDevolucion.calcularPosterioridad(
        prestamo.getFechaPrestamo())){
            frmDevolucion.areaResultados.setText("La fecha de devolución debe ser posterior a la fecha de préstamo");
            return;
        }
        
        if(intCantidad != prestamo.getMyUsuario().getCantidadLibros()){frmDevolucion.areaResultados.setText("Debe devolver la misma cantidad prestada de libros");
            return;
        }
        
        
        libroSeleccionado.setCopias(libroSeleccionado.getCopias() + intCantidad);
        diasTranscurridos = fechaDevolucion.calcularDias(prestamo.getFechaPrestamo());
        int diasPermitidos = prestamo.getMyUsuario().getPlazo();
        if(diasTranscurridos > diasPermitidos){
            prestamo.setMyEstadoPrestamo(EstadoPrestamo.MULTADO);
        }
        else{
            prestamo.setMyEstadoPrestamo(EstadoPrestamo.DEVUELTO);
        }
        controladorPrestamo.getListaPrestamos().remove(prestamo);
            System.out.println("=== DATOS DE LA DEVOLUCION ===");
                System.out.println("Código de Usuario: " + intCodigo);
                System.out.println("Libro: " + libroSeleccionado.getTitulo()); 
                System.out.println("Cantidad Devuelta: " + intCantidad); 
                System.out.println("Fecha Prestamo: " + prestamo.getFechaPrestamo()); 
                System.out.println("Fecha Devolucion: " + fechaDevolucion); 
                System.out.println("Dias transcurridos: " + diasTranscurridos); 
                System.out.println("Estado del Prestamo: " + prestamo.getMyEstadoPrestamo()); 
                System.out.println("-------------------------");   
            
                limpiarCampos();
            }

        public void limpiarCampos(){
          frmDevolucion.txtCodigo.setText("");
          frmDevolucion.txtCopias.setText("");
          frmDevolucion.txtFechaDevolucion.setText("");
          frmDevolucion.txtCodigo.requestFocus();

        }

        public void imprimirResultados() {
            if(prestamo == null){
                frmDevolucion.areaResultados.setText("No hay devoluciones registradas");
                return;
            }
            resultado = "";
            
        resultado += "=== DATOS DE LA DEVOLUCIÓN ==="+"\nCódigo Usuario: " + intCodigo+ "\nLibro: " + libroSeleccionado.getTitulo()+ "\nCantidad Devuelta: " + intCantidad+ "\nFecha Préstamo: " + prestamo.getFechaPrestamo()+ "\nFecha Devolución: " + fechaDevolucion+ "\nDías Transcurridos: " + diasTranscurridos+"\nEstado: " + prestamo.getMyEstadoPrestamo();
        frmDevolucion.areaResultados.setText(resultado);
        }
        public String entregarResultados(){
            
            return resultado;
        }
}

