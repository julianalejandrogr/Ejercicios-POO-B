/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author crist
 */
public class Estudiante extends Usuario{
    private int plazo;

    public Estudiante(String tipoUsuario, int plazo, String nombre, String apellido, int codigo, int cantidadLibros, Libro titulo) {
        super(tipoUsuario,nombre, apellido, codigo, cantidadLibros, titulo);
        this.plazo = plazo;
    }

    public Estudiante(){
    }

    @Override
    public int getPlazo() {
        return plazo;
    }

    public void setPlazo(int plazo) {
        this.plazo = plazo;
    }
    
    
  

    
}
