/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Main;
import Vista.JFPrestamo;
import Vista.JFLibro;
import Vista.JFDevolucion;
import Controlador.ControladorPrestamo;
import Controlador.ControladorLibro;
import Controlador.ControladorDevolucion;
/**
 *
 * @author Esstudiante
 */
public class ProyectoBiblioteca {

    public static void main(String[] args) {
        JFLibro frmLibro = new JFLibro();
        frmLibro.setVisible(true);
        ControladorLibro ctrlLibro = new ControladorLibro(frmLibro);
        
        JFPrestamo frmPrestamo = new JFPrestamo();
        frmPrestamo.setVisible(true);
        ControladorPrestamo ctrlPrestamo = new ControladorPrestamo(frmPrestamo, ctrlLibro);
        
        JFDevolucion frmDevolucion = new JFDevolucion();
        frmDevolucion.setVisible(true);
        ControladorDevolucion ctrlDevolucion = new ControladorDevolucion(frmDevolucion, ctrlLibro, ctrlPrestamo);
    }
}
