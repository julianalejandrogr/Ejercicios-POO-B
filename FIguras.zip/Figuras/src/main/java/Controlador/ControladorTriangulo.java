
package Controlador;
import Vista.JFTriangulo;
import Modelo.Triangulo;
import Controlador.ControladorFigura;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Usuario
 */
public class ControladorTriangulo implements ActionListener {
    private JFTriangulo frmTriangulo;

    public ControladorTriangulo(JFTriangulo frmTriangulo) {
        this.frmTriangulo = frmTriangulo;
        frmTriangulo.btnGuardarTriangulo.addActionListener(this);
    }

    
    

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == frmTriangulo.btnGuardarTriangulo){
            GuardarTriangulo();
        }
        
    }
    public void GuardarTriangulo(){
        double lado1 = Double.parseDouble(frmTriangulo.txtLado1.getText());
        double lado2 = Double.parseDouble(frmTriangulo.txtLado2.getText());
        double lado3 = Double.parseDouble(frmTriangulo.txtLado3.getText());
        
        double lado1c = Math.pow(lado1, 2);
        double lado2c = Math.pow(lado2, 2);
        double lado3c = Math.pow(lado3, 2);
        
        
        if(lado1 == Math.round(Math.sqrt(lado2c+lado3c))||lado2 == Math.round(Math.sqrt(lado1c+lado3c))||lado3 == Math.round(Math.sqrt(lado1c+lado2c))){
            frmTriangulo.txtMostrar.setText("Es triangulo rectangulo");
            if (lado1 == Math.round(Math.sqrt(lado2c + lado3c))){
                double area = (lado2*lado3)/2;
                frmTriangulo.txtMostrar.setText("Es triangulo rectangulo"+"\n"+"El area es: "+area);
                
                
            }else if((lado2 == Math.round(Math.sqrt(lado1c + lado3c)))){
                double area = (lado1*lado3)/2;
                frmTriangulo.txtMostrar.setText("Es triangulo rectangulo"+"\n"+"El area es: "+area);
                
            }else if(lado3 == Math.round(Math.sqrt(lado1c + lado2c))){
                double area = (lado1*lado2)/2;
                frmTriangulo.txtMostrar.setText("Es triangulo rectangulo"+"\n"+"El area es: "+area);
                
                
            }
        }
        else{
            
            double s = (lado1 + lado2 + lado3) / 2.0; 
            double area = Math.sqrt(s * (s - lado1) * (s - lado2) * (s - lado3));
            frmTriangulo.txtMostrar.setText("Es triangulo"+"\n"+"El area es: "+area);
        }
        
    }
    
}
