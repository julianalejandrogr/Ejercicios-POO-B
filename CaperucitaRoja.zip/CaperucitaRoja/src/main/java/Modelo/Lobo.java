package Modelo;

/**
 *
 * @author fabian
 */
public class Lobo extends Personaje{
    private boolean vivo;

    public Lobo() {
    }

    public Lobo(boolean vivo, String nombre, String tipo, String caracteristica) {
        super(nombre, tipo, caracteristica);
        this.vivo = vivo;
    }

    public boolean isVivo() {
        return vivo;
    }

    public void setVivo(boolean vivo) {
        this.vivo = vivo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCaracteristica() {
        return caracteristica;
    }

    public void setCaracteristica(String caracteristica) {
        this.caracteristica = caracteristica;
    }

    @Override
    public String toString() {
        return "\nNombre = "+ nombre +"\nRol = "+tipo+"\nCaracteristica = "+ caracteristica + "\nVivo? = " + vivo;
    }
    
}
