package Modelo;

/**
 *
 * @author fabian
 */
public class Cazador extends Personaje{
    private String arma;

    public Cazador() {
    }
    
    public Cazador(String arma, String nombre, String tipo, String caracteristica) {
        super(nombre, tipo, caracteristica);
        this.arma = arma;
    }

    public String getArma() {
        return arma;
    }

    public void setArma(String arma) {
        this.arma = arma;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCaracteristica() {
        return caracteristica;
    }

    public void setCaracteristica(String caracteristica) {
        this.caracteristica = caracteristica;
    }

    @Override
    public String toString() {
        return "\nNombre = "+ nombre +"\nRol = "+tipo+"\nCaracteristica = "+ caracteristica +"\nArma = "+ arma;
    }
    
}
