package Modelo;

/**
 *
 * @author fabian
 */
public class Caperucita extends Personaje{
    private boolean rescatada;
    private String estado;
    private Cesta cesta;

    public Caperucita() {
    }
    
    public Caperucita(boolean rescatada, Cesta cesta, String estado,String nombre, String tipo, String caracteristica) {
        super(nombre, tipo, caracteristica);
        this.rescatada = rescatada;
        this.cesta = cesta;
        this.estado = estado;
    }

    public boolean isRescatada() {
        return rescatada;
    }

    public void setRescatada(boolean rescatada) {
        this.rescatada = rescatada;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCaracteristica() {
        return caracteristica;
    }

    public void setCaracteristica(String caracteristica) {
        this.caracteristica = caracteristica;
    }

    public Cesta getCesta() {
        return cesta;
    }

    public void setCesta(Cesta cesta) {
        this.cesta = cesta;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "\nNombre = "+ nombre +"\nRol = "+tipo+"\nCaracteristica = "+ caracteristica +"\nrescatada? = " + rescatada + "\n" + cesta.toString() +"\nEstado = " + estado;
    }
    
}
