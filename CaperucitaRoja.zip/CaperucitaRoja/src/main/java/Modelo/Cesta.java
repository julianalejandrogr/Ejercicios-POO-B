package Modelo;

/**
 *
 * @author fabian
 */
public class Cesta {
    private boolean comida = false;
    private boolean bebida = false;

    public Cesta() {
    }

    public Cesta(boolean comida, boolean bebida) {
        this.comida = comida;
        this.bebida = bebida;
    }

    public boolean isComida() {
        return comida;
    }

    public void setComida(boolean comida) {
        this.comida = comida;
    }

    public boolean isBebida() {
        return bebida;
    }

    public void setBebida(boolean bebida) {
        this.bebida = bebida;
    }

    @Override
    public String toString() {
        return "Cesta\nComida = " + comida + "\nBebida = " + bebida;
    }
    
}
