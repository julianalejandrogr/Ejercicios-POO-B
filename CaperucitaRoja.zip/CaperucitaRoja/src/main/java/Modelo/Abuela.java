package Modelo;

/**
 *
 * @author fabian
 */
public class Abuela extends Personaje{
    private int edad;
    private String salud;
    private boolean rescatada;
    private String estado;

    public Abuela() {
    }

    public Abuela(int edad, String salud, boolean rescatada, String estado, String nombre, String tipo, String caracteristica) {
        super(nombre, tipo, caracteristica);
        this.edad = edad;
        this.salud = salud;
        this.rescatada = rescatada;
        this.estado = estado;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getSalud() {
        return salud;
    }

    public void setSalud(String salud) {
        this.salud = salud;
    }

    public boolean isRescatada() {
        return rescatada;
    }

    public void setRescatada(boolean rescatada) {
        this.rescatada = rescatada;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCaracteristica() {
        return caracteristica;
    }

    public void setCaracteristica(String caracteristica) {
        this.caracteristica = caracteristica;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "\nNombre = "+ nombre +"\nRol = "+tipo+"\nCaracteristica = "+ caracteristica + "\nEdad = "+ edad +"\nSalud = "+ salud +"\nRescatada? = "+ rescatada +"\nEstado = " + estado;
    }
    
}
