package Modelo;

/**
 *
 * @author fabian
 */
public abstract class Personaje {
    protected String nombre;
    protected String tipo;
    protected String caracteristica;

    public Personaje() {
    }

    public Personaje(String nombre, String tipo, String caracteristica) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.caracteristica = caracteristica;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Personaje{" + "nombre=" + nombre + ", tipo=" + tipo + '}';
    }
    
}
