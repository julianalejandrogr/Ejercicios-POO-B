package Controlador;

import Vista.JFCaperucita;
import Modelo.Abuela;
import Modelo.Caperucita;
import Modelo.Cesta;
import Modelo.Cazador;
import Modelo.Lobo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author fabian
 */
public class ControladorCaperucita implements ActionListener{
    private String msg="";
    private int contador = 0;
    private JFCaperucita frmCaperucita;
    private Cesta cesta;
    private Caperucita cap;
    private Abuela ab;
    private Lobo l;
    private Cazador caz;
    public ControladorCaperucita(JFCaperucita frmCaperucita){
        this.frmCaperucita = frmCaperucita;
        this.frmCaperucita.btnAvanzar.addActionListener(this);
        this.frmCaperucita.btnReiniciar.addActionListener(this);
        this.cesta = new Cesta(false, false);
        this.cap = new Caperucita(false, cesta, "Normal","Caperucita Roja", "Protagonista", "Caperuza o gorro\nde color rojo");
        this.ab = new Abuela(80, "Enferma y debil", false, "Normal", "Abuela de Caperucita Roja", "Personaje secundario", "Un gorro");
        this.l = new Lobo(true, "Lobo", "Villano", "Orejas grandes, Ojos grandes\nBrazos grandes, Boca grande");
        this.caz = new Cazador("Escopeta", "Cazador", "Personaje Secundario", "Ademas de su arma\nlleva unas tijeras con el");
    }
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == frmCaperucita.btnAvanzar){
            avanzarCuento();
            contador++;
        }
        if(e.getSource() == frmCaperucita.btnReiniciar){
            reinciarCuento();
            contador = 0;
        }
    }
    
    public void avanzarCuento(){
        switch(contador){
            case 0:
                frmCaperucita.lblCaperucita.setVisible(true);
                frmCaperucita.areaCuento.append("Había una vez una adorable niña que era querida por todo\n"
                        + "aquél que la conociera, pero sobre todo por su\n"
                        + "abuelita, y no quedaba nada que no le hubiera dado a la\n"
                        + "niña. Una vez le regaló una pequeña caperuza o gorrito de\n"
                        + "un color rojo, que le quedaba tan bien que ella nunca\n"
                        + "quería usar otra cosa, así que la empezaron a llamar\n"
                        + "Caperucita Roja.\n");
                msg += cap.toString();
                frmCaperucita.areaInfo.setText(msg);
                break;
            case 1:
                cesta.setBebida(true);
                cesta.setComida(true);
                cap.setCesta(cesta);
                frmCaperucita.areaCuento.append("Un día su madre le dijo: \"Ven, Caperucita Roja, aquí tengo\n"
                        + " un pastel y una botella de vino, llévaselas en esta \n"
                        + "canasta a tu abuelita que esta enfermita y débil y esto\n"
                        + "le ayudará. Vete ahora temprano, antes de que caliente\n"
                        + "el día, y en el camino, camina tranquila y con cuidado,\n"
                        + "no te apartes de la ruta, no vayas a caerte y se quiebre\n"
                        + "la botella y no quede nada para tu abuelita. Y cuando\n"
                        + "entres a su dormitorio no olvides decirle, \"Buenos días,\"\n"
                        + "ah, y no andes curioseando por todo el aposento.\"\n");
                msg =cap.toString() + "\n" + ab.toString();
                frmCaperucita.areaInfo.setText(msg);
                break;
            case 2:
                frmCaperucita.areaCuento.append("\"No te preocupes, haré bien todo,\" dijo Caperucita Roja,\n"
                        + "y tomó las cosas y se despidió cariñosamente. La abuelita\n"
                        + "vivía en el bosque, como a un kilómetro de su casa. Y no\n"
                        + "más había entrado Caperucita Roja en el bosque, siempre\n"
                        + "dentro del sendero, cuando se encontró con un lobo.\n");
                msg +="\n"+l.toString();
                frmCaperucita.areaInfo.setText(msg);
                break;
            case 3:
                frmCaperucita.lblLobo.setVisible(true);
                frmCaperucita.lblCaperucita.setBounds(420, 260, 150, 150);
                frmCaperucita.areaCuento.append("Caperucita Roja no sabía que esa criatura pudiera hacer algún\n"
                        + " daño, y no tuvo ningún temor hacia él. \"Buenos días,\n"
                        + "Caperucita Roja,\" dijo el lobo. \"Buenos días, amable\n"
                        + "lobo.\" - \"¿Adonde vas tan temprano, Caperucita Roja?\"\n"
                        + " - \"A casa de mi abuelita.\" - \"¿Y qué llevas en esa\n"
                        + "canasta?\" - \"Pastel y vino. Ayer fue día de hornear,\n"
                        + "así que mi pobre abuelita enferma va a tener algo bueno\n"
                        + "para fortalecerse.\" - \"¿Y adonde vive tu abuelita,\n"
                        + "Caperucita Roja?\" - \"Como a medio kilómetro más adentro\n"
                        + "en el bosque. Su casa está bajo tres grandes robles, al lado\n"
                        + "de unos avellanos. Seguramente ya los habrás visto,\"\n"
                        + "contestó inocentemente Caperucita Roja.\n");
                frmCaperucita.areaInfo.setText(msg);
                break;
            case 4:
                frmCaperucita.areaCuento.append("El lobo se dijo en silencio a sí mismo: \"¡Qué criatura tan tierna!\n"
                        + "qué buen bocadito - y será más sabroso que esa viejita.\n"
                        + "Así que debo actuar con delicadeza para obtener a ambas\n"
                        + "fácilmente.\" Entonces acompañó a Caperucita Roja un pequeño\n"
                        + "tramo del camino y luego le dijo: \"Mira Caperucita Roja, que\n"
                        + "lindas flores se ven por allá, ¿por qué no vas y recoges algunas?\n"
                        + "Y yo creo también que no te has dado cuenta de lo dulce que\n"
                        + "cantan los pajaritos. Es que vas tan apurada en el camino\n"
                        + "como si fueras para la escuela, mientras que todo el bosque\n"
                        + "está lleno de maravillas.\"\n");
                frmCaperucita.areaInfo.setText(msg);
                break;
            case 5:
                frmCaperucita.lblCaperucita.setBounds(560, 200, 150, 150);
                frmCaperucita.areaCuento.append("Caperucita Roja levantó sus ojos, y cuando vio los rayos del sol\n"
                        + "danzando aquí y allá entre los árboles, y vio las bellas flores y el\n"
                        + "canto de los pájaros, pensó: \"Supongo que podría llevarle unas\n"
                        + "de estas flores frescas a mi abuelita y que le encantarán.\n"
                        + "Además, aún es muy temprano y no habrá problema si me atraso\n"
                        + "un poquito, siempre llegaré a buena hora.\" Y así, ella se\n"
                        + "salió del camino y se fue a cortar flores.\n");
                frmCaperucita.areaInfo.setText(msg);
                break;
            case 6:
                frmCaperucita.lblLobo.setBounds(750, 310, 150, 150);
                frmCaperucita.areaCuento.append("Y cuando cortaba una, veía otra más bonita, y otra y otra, y sin\n"
                        + "darse cuenta se fue adentrando en el bosque. Mientras tanto el\n"
                        + "lobo aprovechó el tiempo y corrió directo a la casa de la\n"
                        + "abuelita y tocó a la puerta. \"¿Quién es?\" preguntó la\n"
                        + "abuelita. \"Caperucita Roja,\" contestó el lobo. \"Traigo\n"
                        + " pastel y vino. Ábreme, por favor.\" - \" Mueve la \n"
                        + "cerradura y abre tú,\" gritó la abuelita, \"estoy muy débil y no\n"
                        + "me puedo levantar.\"\n");
                frmCaperucita.areaInfo.setText(msg);
                break;
            case 7:
                frmCaperucita.lblLobo.setVisible(false);
                ab.setEstado("Tragada por el lobo");
                frmCaperucita.areaCuento.append("El lobo movió la cerradura, abrió la puerta, y sin decir una\n"
                        + "palabra más, se fue directo a la cama de la abuelita y\n"
                        + " de un bocado se la tragó. Y enseguida se puso ropa de\n"
                        + "ella, se colocó un gorro, se metió en la cama y cerró\n"
                        + "las cortinas.\n");
                msg =cap.toString() + "\n" + ab.toString() + "\n" + l.toString();
                frmCaperucita.areaInfo.setText(msg);
                break;
            case 8:
                frmCaperucita.lblCaperucita.setBounds(450, 300, 150, 150);
                frmCaperucita.areaCuento.append("Mientras tanto, Caperucita Roja se había quedado colectando\n"
                        + "flores, y cuando vio que tenía tantas que ya no podía\n"
                        + "llevar más, se acordó de su abuelita y se puso en\n"
                        + "camino hacia ella.\n");
                frmCaperucita.areaInfo.setText(msg);
                break;
            case 9:
                frmCaperucita.lblCaperucita.setBounds(750, 310, 150, 150);
                frmCaperucita.areaCuento.append("Cuando llegó, se sorprendió al encontrar la puerta abierta, y\n"
                        + "al entrar a la casa, sintió tan extraño presentimiento\n"
                        + "que se dijo para sí misma: \"¡Oh Dios! que incómoda me\n"
                        + "siento hoy, y otras veces que me ha gustado tanto estar\n"
                        + "con abuelita.\" Entonces gritó: \"¡Buenos días!,\" pero\n"
                        + "no hubo respuesta, así que fue al dormitorio y abrió las\n"
                        + " cortinas.\n");
                frmCaperucita.areaInfo.setText(msg);
                break;
            case 10:
                frmCaperucita.lblCaperucita.setVisible(false);
                cap.setEstado("Tragada por el lobo");
                frmCaperucita.areaCuento.append("Allí parecía estar la abuelita con su gorro cubriéndole toda la\n"
                        + "cara, y con una apariencia muy extraña. \"¡!Oh, abuelita!\"\n"
                        + " dijo, \"qué orejas tan grandes que tienes.\" - \"Es para\n"
                        + "oírte mejor, mi niña,\" fue la respuesta. \"Pero abuelita,\n"
                        + "qué ojos tan grandes que tienes.\" - \"Son para verte mejor,\n"
                        + "querida.\" - \"Pero abuelita, qué brazos tan grandes que\n"
                        + "tienes.\" - \"Para abrazarte mejor.\" - \"Y qué boca tan\n"
                        + "grande que tienes.\" - \"Para comerte mejor.\" Y no había\n"
                        + "terminado de decir lo anterior, cuando de un salto salió de\n"
                        + "la cama y se tragó también a Caperucita Roja.\n");
                msg =cap.toString() + "\n" + ab.toString() + "\n" + l.toString();
                frmCaperucita.areaInfo.setText(msg);
                break;
            case 11:
                frmCaperucita.lblCazador.setVisible(true);
                frmCaperucita.areaCuento.append("Entonces el lobo decidió hacer una siesta y se volvió a tirar en\n"
                        + "la cama, y una vez dormido empezó a roncar fuertemente.\n"
                        + "Un cazador que por casualidad pasaba en ese momento por\n"
                        + "allí, escuchó los fuertes ronquidos y pensó, ¡Cómo ronca esa\n"
                        + "viejita! Voy a ver si necesita alguna ayuda.\n");
                msg += "\n" + caz.toString();
                frmCaperucita.areaInfo.setText(msg);
                break;
            case 12:
                frmCaperucita.lblCazador.setVisible(false);
                frmCaperucita.areaCuento.append("Entonces ingresó al dormitorio, y cuando se acercó a la cama vio\n"
                        + "al lobo tirado allí. \"¡Así que te encuentro aquí, viejo pecador!\"\n"
                        + " dijo él. \"¡Hacía tiempo que te buscaba!\" Y ya se disponía a\n"
                        + "disparar su arma contra él, cuando pensó que el lobo podría\n"
                        + "haber devorado a la viejita y que aún podría ser salvada, por\n"
                        + " lo que decidió no disparar.\n");
                frmCaperucita.areaInfo.setText(msg);
                break;
            case 13:
                frmCaperucita.lblAbuela.setVisible(true);
                frmCaperucita.lblCaperucita.setVisible(true);
                frmCaperucita.lblCaperucita.setBounds(610, 400, 150, 150);
                cap.setEstado("Asustada");
                ab.setEstado("Asustada");
                cap.setRescatada(true);
                ab.setRescatada(true);
                frmCaperucita.areaCuento.append("En su lugar tomó unas tijeras y empezó a cortar el vientre del\n"
                        + "lobo durmiente. En cuanto había hecho dos cortes, vio brillar\n"
                        + "una gorrita roja, entonces hizo dos cortes más y la pequeña\n"
                        + "Caperucita Roja salió rapidísimo, gritando: \"¡Qué asustada\n"
                        + "que estuve, qué oscuro que está ahí dentro del lobo!,\" y\n"
                        + "enseguida salió también la abuelita, vivita, pero que casi no\n"
                        + "podía respirar.\n");
                msg =cap.toString() + "\n" + ab.toString() + "\n" + l.toString() + "\n" + caz.toString();
                frmCaperucita.areaInfo.setText(msg);
                break;
            case 14:
                frmCaperucita.lblCazador.setVisible(true);
                l.setVivo(false);
                frmCaperucita.areaCuento.append("Rápidamente, Caperucita Roja trajo muchas piedras con las que\n"
                        + "llenaron el vientre del lobo. Y cuando el lobo despertó, quizo\n"
                        + "correr e irse lejos, pero las piedras estaban tan pesadas que\n"
                        + "no soportó el esfuerzo y cayó muerto.\n");
                msg =cap.toString() + "\n" + ab.toString() + "\n" + l.toString() + "\n" + caz.toString();
                frmCaperucita.areaInfo.setText(msg);
                break;
            case 15:
                frmCaperucita.lblCazador.setVisible(false);
                cap.setEstado("Feliz");
                ab.setEstado("Feliz");
                cesta.setBebida(false);
                cesta.setComida(false);
                frmCaperucita.areaCuento.append("Las tres personas se sintieron felices. El cazador le quitó la\n"
                        + "piel al lobo y se la llevó a su casa. La abuelita comió el\n"
                        + "pastel y bebió el vino que le trajo Caperucita Roja y se reanimó.\n"
                        + "Pero Caperucita Roja solamente pensó: \"Mientras viva, nunca me\n"
                        + "retiraré del sendero para internarme en el bosque, cosa que mi\n"
                        + "madre me había ya prohibido hacer.\"");
                msg =cap.toString() + "\n" + ab.toString() + "\n" + l.toString() + "\n" + caz.toString();
                frmCaperucita.areaInfo.setText(msg);
                break;
        }
    }
    
    public void reinciarCuento(){
        frmCaperucita.lblCaperucita.setBounds(120, 20, 150, 150);
        frmCaperucita.lblAbuela.setBounds(680, 350, 150, 150);
        frmCaperucita.lblLobo.setBounds(450, 220, 150, 150);
        frmCaperucita.lblCazador.setBounds(750, 310, 150, 150);
        frmCaperucita.lblCabana1.setBounds(800, 370, 150, 150);
        frmCaperucita.lblCabana2.setBounds(200, 2, 150, 150);
        frmCaperucita.lblCaperucita.setVisible(false);
        frmCaperucita.lblAbuela.setVisible(false);
        frmCaperucita.lblLobo.setVisible(false);
        frmCaperucita.lblCazador.setVisible(false);
        frmCaperucita.lblCabana1.setVisible(true);
        frmCaperucita.lblCabana2.setVisible(true);
        msg ="";
        frmCaperucita.areaCuento.setText("");
        frmCaperucita.areaInfo.setText("");
    }
}
