/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package Main;

import Vista.*;
import Controlador.ControladorDueño;
import Controlador.ControladorMascota;
import Controlador.ControladorCuidador;
import Controlador.ControladorMain;
import Controlador.ControladorReserva;

/**
 *
 * @author Estudiante
 */
public class HotelMascotas {

    public static void main(String[] args) {
        JFMain frmMain = new JFMain();
        frmMain.setVisible(true);
        ControladorMain ctrlMain = new ControladorMain(frmMain);
    }
}
