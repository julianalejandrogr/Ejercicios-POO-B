/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Estudiante
 */
public class Cuidador {
    private String nombre;
    private String apellido;
    private String nivelExperiencia;
    private String especies;
    private boolean disponible;

    public Cuidador(String nombre, String apellido, String nivelExperiencia, String especies) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.nivelExperiencia = nivelExperiencia;
        this.especies = especies;
        this.disponible = true;
    }

    public Cuidador() {}

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNivelExperiencia() {
        return nivelExperiencia;
    }

    public void setNivelExperiencia(String nivelExperiencia) {
        this.nivelExperiencia = nivelExperiencia;
    }

    public String getEspecies() {
        return especies;
    }

    public void setEspecies(String especies) {
        this.especies = especies;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    @Override
    public String toString() {
        return nombre + " " + apellido + " - " + nivelExperiencia;
    }
}
