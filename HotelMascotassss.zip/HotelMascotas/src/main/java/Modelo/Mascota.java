/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Estudiante
 */
public class Mascota {
    private String nombre;
    private String especie;
    private String raza;
    private int edad;
    private String necesidades;
    private DueñoMascota dueño;

    public Mascota(String nombre, String especie, String raza, int edad, String necesidades, DueñoMascota dueño) {
        this.nombre = nombre;
        this.especie = especie;
        this.raza = raza;
        this.edad = edad;
        this.necesidades = necesidades;
        this.dueño = dueño;
    }

    public Mascota() {}

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getNecesidades() {
        return necesidades;
    }

    public void setNecesidades(String necesidades) {
        this.necesidades = necesidades;
    }

    public DueñoMascota getDueño() {
        return dueño;
    }

    public void setDueño(DueñoMascota dueño) {
        this.dueño = dueño;
    }

    @Override
    public String toString() {
        return nombre + " (" + especie + ")";
    }
}
