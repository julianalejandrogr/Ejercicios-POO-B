/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Estudiante
 */
public class Reserva {
    private Mascota mascota;
    private Fecha fechaIngreso;
    private int diasEstadia;
    private String servicios;
    private Cuidador cuidador;
    private EstadoReserva estado;

    public Reserva(Mascota mascota, Fecha fechaIngreso, int diasEstadia, String servicios) {
        this.mascota = mascota;
        this.fechaIngreso = fechaIngreso;
        this.diasEstadia = diasEstadia;
        this.servicios = servicios;
        this.cuidador = null;
        this.estado = EstadoReserva.ACTIVA;
    }

    public Reserva() {}

    public Mascota getMascota() {
        return mascota;
    }

    public void setMascota(Mascota mascota) {
        this.mascota = mascota;
    }

    public Fecha getFechaIngreso() {
        return fechaIngreso;
    }

    public void setFechaIngreso(Fecha fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public int getDiasEstadia() {
        return diasEstadia;
    }

    public void setDiasEstadia(int diasEstadia) {
        this.diasEstadia = diasEstadia;
    }

    public String getServicios() {
        return servicios;
    }

    public void setServicios(String servicios) {
        this.servicios = servicios;
    }

    public Cuidador getCuidador() {
        return cuidador;
    }

    public void setCuidador(Cuidador cuidador) {
        this.cuidador = cuidador;
    }

    public EstadoReserva getEstado() {
        return estado;
    }

    public void setEstado(EstadoReserva estado) {
        this.estado = estado;
    }
    public void asignarCuidador(Cuidador cuidador) {
        // 1. Validar disponibilidad del cuidador
        if (!cuidador.isDisponible()) {
            throw new IllegalArgumentException("El cuidador seleccionado no está disponible");
        }
        
        // 2. Validar que el cuidador atienda la especie de la mascota
        String especieMascota = this.mascota.getEspecie();
        if (!cuidador.getEspecies().contains(especieMascota.toUpperCase())) {
            throw new IllegalArgumentException("El cuidador no atiende la especie de esta mascota");
        }
        
        // 3. Modificar los estados si todo es correcto
        this.cuidador = cuidador;
        cuidador.setDisponible(false);
        this.estado = EstadoReserva.ASIGNADA;
    }

    @Override
    public String toString() {
        return mascota.getNombre() + " - " + fechaIngreso + " (" + diasEstadia + " dias) - " + estado;
    }
    
}
