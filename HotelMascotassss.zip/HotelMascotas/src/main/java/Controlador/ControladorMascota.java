/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.DueñoMascota;
import Modelo.Mascota;
import Vista.JFMain;
import Vista.JFMascota;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 *
 * @author Estudiante
 */
public class ControladorMascota implements ActionListener {
    private JFMain jfMain;
    private JFMascota frmMascota;
    private ArrayList<Mascota> listaMascotas;
    private ArrayList<DueñoMascota> listaDueños;
    private ControladorDueño controladorDueño;

    public ArrayList<Mascota> getListaMascotas() {
        return listaMascotas;
    }

    public ControladorMascota(JFMascota frmMascota, ControladorDueño controladorDueño, JFMain jfMain) {
        this.jfMain = jfMain;
        this.frmMascota = frmMascota;
        this.listaMascotas = new ArrayList<>();
        this.listaDueños = controladorDueño.getListaDueños();
        this.controladorDueño = controladorDueño;
        this.frmMascota.btnGuardar.addActionListener(this);
        this.frmMascota.btnLimpiar.addActionListener(this);
        this.frmMascota.btnMostrar.addActionListener(this);
        this.frmMascota.btnCargar.addActionListener(this);
        this.frmMascota.btAtras.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmMascota.btnGuardar) {
            guardarMascota();
        }
        if (e.getSource() == frmMascota.btnLimpiar) {
            limpiarCampos();
        }
        if (e.getSource() == frmMascota.btnMostrar) {
            mostrarMascotas();
        }
        if (e.getSource() == frmMascota.btnCargar) {
            cargarDueños();
        }
        if (e.getSource() == frmMascota.btAtras) {
            this.jfMain.setVisible(true);
            this.limpiarCampos();
            this.frmMascota.areaResultados.setText("");
            this.frmMascota.setVisible(false);
        }
    }
    public void cargarDueños(){
    frmMascota.comboDueño.removeAllItems();
    for(DueñoMascota d : controladorDueño.getListaDueños()){
    frmMascota.comboDueño.addItem(d);   
    }
    }
    private void guardarMascota() {
        String nombre = frmMascota.txtNombre.getText();
        String especie = frmMascota.comboEspecie.getSelectedItem().toString();
        String raza = frmMascota.txtRaza.getText();
        String edadStr = frmMascota.txtEdad.getText();
        String necesidades = frmMascota.txtNecesidades.getText();

        if (nombre.isEmpty() || raza.isEmpty() || edadStr.isEmpty()) {
            frmMascota.areaResultados.setText("Todos los campos son obligatorios");
            return;
        }

        if (listaDueños.isEmpty()) {
            frmMascota.areaResultados.setText("Primero debe registrar un dueño");
            return;
        }

        int edad;
        try {
            edad = Integer.parseInt(edadStr);
            if (edad < 0) {
                frmMascota.areaResultados.setText("La edad no puede ser negativa");
                return;
            }
        } catch (NumberFormatException e) {
            frmMascota.areaResultados.setText("La edad debe ser un número entero");
            return;
        }
        int indiceDueño = frmMascota.comboDueño.getSelectedIndex();
        DueñoMascota dueño = listaDueños.get(indiceDueño);
        for(Mascota m : listaMascotas){
            if(m.getNombre().equalsIgnoreCase(nombre)&& m.getDueño().equals(dueño)){

        frmMascota.areaResultados.setText(
            "Ese dueño ya tiene una mascota registrada con ese nombre"
        );
        return; }
        }
        
        Mascota mascota = new Mascota(nombre, especie, raza, edad, necesidades, dueño);
        listaMascotas.add(mascota);
        frmMascota.areaResultados.setText("Mascota registrada correctamente");
        limpiarCampos();
    }

    private void limpiarCampos() {
        frmMascota.txtNombre.setText("");
        frmMascota.comboEspecie.setSelectedIndex(0);
        frmMascota.txtRaza.setText("");
        frmMascota.txtEdad.setText("");
        frmMascota.txtNecesidades.setText("");
        frmMascota.txtNombre.requestFocus();
    }

    private void mostrarMascotas() {
        if (listaMascotas.isEmpty()) {
            frmMascota.areaResultados.setText("No hay mascotas registradas");
            return;
        }
        String resultado = "";
        for (Mascota m : listaMascotas) {
            resultado += "\n=== MASCOTA ===";
            resultado += "\nNombre: " + m.getNombre();
            resultado += "\nEspecie: " + m.getEspecie();
            resultado += "\nRaza: " + m.getRaza();
            resultado += "\nEdad: " + m.getEdad() + " años";
            resultado += "\nNecesidades: " + m.getNecesidades();
            resultado += "\nDueño: " + m.getDueño().getNombre() + " " + m.getDueño().getApellido();
            resultado += "\n----------------------------";
        }
        frmMascota.areaResultados.setText(resultado);
    }
}
