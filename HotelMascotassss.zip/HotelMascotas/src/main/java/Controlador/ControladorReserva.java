/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Cuidador;
import Modelo.Fecha;
import Modelo.Mascota;
import Modelo.Reserva;
import Modelo.EstadoReserva;
import Vista.JFMain;
import Vista.JFReserva;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import static java.lang.Integer.parseInt;

/**
 *
 * @author Estudiante
 */
public class ControladorReserva implements ActionListener {
    private JFMain jfMain;
    private JFReserva frmReserva;
    private ArrayList<Reserva> listaReservas;
    private ArrayList<Mascota> listaMascotas;
    private ArrayList<Cuidador> listaCuidadores;

    public ControladorReserva(JFReserva frmReserva, ControladorMascota ctrlMascota, ControladorCuidador ctrlCuidador, JFMain jfMain) {
        this.jfMain = jfMain;
        this.frmReserva = frmReserva;
        this.listaReservas = new ArrayList<>();
        this.listaMascotas = ctrlMascota.getListaMascotas();
        this.listaCuidadores = ctrlCuidador.getListaCuidadores();
        this.frmReserva.btnGuardar.addActionListener(this);
        this.frmReserva.btnLimpiar.addActionListener(this);
        this.frmReserva.btnMostrar.addActionListener(this);
        this.frmReserva.btnAsignar.addActionListener(this);
        this.frmReserva.btnCargar.addActionListener(this);
        this.frmReserva.btAtras.addActionListener(this);
    }

    public void cargarCombos() {
        frmReserva.comboMascota.removeAllItems();
        for (Mascota m : listaMascotas) {
            frmReserva.comboMascota.addItem(m.getNombre() + " (" + m.getEspecie() + ")");
        }
        frmReserva.comboCuidador.removeAllItems();
        for (Cuidador c : listaCuidadores) {
            frmReserva.comboCuidador.addItem(c.getNombre() + " " + c.getApellido());
        }
        frmReserva.comboReserva.removeAllItems();
        for (Reserva r : listaReservas){
            frmReserva.comboReserva.addItem(r.toString());
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmReserva.btnGuardar) {
            guardarReserva();
        }
        if (e.getSource() == frmReserva.btnLimpiar) {
            limpiarCampos();
        }
        if (e.getSource() == frmReserva.btnMostrar) {
            mostrarReservas();
        }
        if (e.getSource() == frmReserva.btnAsignar) {
            asignarCuidador();
        }
        if (e.getSource() == frmReserva.btnCargar) {
            cargarCombos();
        }
        if (e.getSource() == frmReserva.btAtras) {
            this.jfMain.setVisible(true);
            this.limpiarCampos();
            this.frmReserva.areaResultados.setText("");
            this.frmReserva.setVisible(false);
        }
    }

    private void guardarReserva() {
        String fechaStr = frmReserva.txtFechaIngreso.getText();
        String diasStr = frmReserva.txtDias.getText();

        if (listaMascotas.isEmpty()) {
            frmReserva.areaResultados.setText("Primero debe registrar una mascota");
            return;
        }

        if (fechaStr.isEmpty() || diasStr.isEmpty()) {
            frmReserva.areaResultados.setText("La fecha y los días de estadía son obligatorios");
            return;
        }

        String[] fechas = fechaStr.split("/");
        int dia = 0;
        int mes = 0;
        int año = 0;

        if (fechas.length != 3 || fechas[0].length() != 2 || fechas[1].length() != 2 || fechas[2].length() != 4) {
            frmReserva.areaResultados.setText("La fecha debe tener formato dd/mm/aaaa");
            return;
        }

        try {
            dia = parseInt(fechas[0]);
            mes = parseInt(fechas[1]);
            año = parseInt(fechas[2]);
        } catch (NumberFormatException e) {
            frmReserva.areaResultados.setText("La fecha contiene caracteres no válidos");
            return;
        }

        Fecha fechaIngreso;
        try {
            fechaIngreso = new Fecha(dia, mes, año);
        } catch (IllegalArgumentException e) {
            frmReserva.areaResultados.setText(e.getMessage());
            return;
        }

        int dias;
        try {
            dias = Integer.parseInt(diasStr);
            if (dias <= 0) {
                frmReserva.areaResultados.setText("Los días de estadía deben ser mayor que cero");
                return;
            }
        } catch (NumberFormatException e) {
            frmReserva.areaResultados.setText("Los días de estadía deben ser un número entero");
            return;
        }

        String servicios = "";
        if (frmReserva.chkAlimentacion.isSelected()) servicios += "Alimentación especial ";
        if (frmReserva.chkPaseo.isSelected())        servicios += "Paseo diario ";
        if (frmReserva.chkBaño.isSelected())          servicios += "Baño y aseo ";
        if (servicios.isEmpty()) servicios = "Ninguno";

        int indiceMascota = frmReserva.comboMascota.getSelectedIndex();
        Mascota mascota = listaMascotas.get(indiceMascota);
        
        for(Reserva r : listaReservas){
            if(r.getMascota().equals(mascota)){frmReserva.areaResultados.setText("Esta mascota ya tiene una reserva registrada");
            return;
            }
        }
        Reserva reserva = new Reserva(mascota, fechaIngreso, dias, servicios);
        listaReservas.add(reserva);

        
        frmReserva.comboReserva.addItem(reserva.toString());

        frmReserva.areaResultados.setText("Reserva guardada correctamente");
        limpiarCampos();
    }

    private void asignarCuidador() {
        if (listaReservas.isEmpty()) {
            frmReserva.areaResultados.setText("No hay reservas para asignar cuidador");
            return;
        }
        if (listaCuidadores.isEmpty()) {
            frmReserva.areaResultados.setText("No hay cuidadores registrados");
            return;
        }

        int indiceReserva = frmReserva.comboReserva.getSelectedIndex();
        int indiceCuidador = frmReserva.comboCuidador.getSelectedIndex();

        if (indiceReserva < 0 || indiceCuidador < 0) {
            frmReserva.areaResultados.setText("Seleccione una reserva y un cuidador");
            return;
        }

        Reserva reserva = listaReservas.get(indiceReserva);
        Cuidador cuidador = listaCuidadores.get(indiceCuidador);
        try {
            reserva.asignarCuidador(cuidador);
            frmReserva.areaResultados.setText("Cuidador " + cuidador.getNombre() + " asignado correctamente a la reserva de " + reserva.getMascota().getNombre());
        } catch (IllegalArgumentException e) {
            frmReserva.areaResultados.setText(e.getMessage());
        }
       
    }

    private void limpiarCampos() {
        frmReserva.txtFechaIngreso.setText("");
        frmReserva.txtDias.setText("");
        frmReserva.chkAlimentacion.setSelected(false);
        frmReserva.chkPaseo.setSelected(false);
        frmReserva.chkBaño.setSelected(false);
        frmReserva.txtFechaIngreso.requestFocus();
    }

    private void mostrarReservas() {
        if (listaReservas.isEmpty()) {
            frmReserva.areaResultados.setText("No hay reservas registradas");
            return;
        }
        String resultado = "";
        for (Reserva r : listaReservas) {
            resultado += "\n=== RESERVA ===";
            resultado += "\nMascota: " + r.getMascota().getNombre();
            resultado += "\nDueño: " + r.getMascota().getDueño().getNombre() + " " + r.getMascota().getDueño().getApellido();
            resultado += "\nFecha de ingreso: " + r.getFechaIngreso();
            resultado += "\nDías de estadía: " + r.getDiasEstadia();
            resultado += "\nServicios: " + r.getServicios();
            resultado += "\nCuidador: " + (r.getCuidador() != null ? r.getCuidador().getNombre() + " " + r.getCuidador().getApellido() : "Sin asignar");
            resultado += "\nEstado: " + r.getEstado();
            resultado += "\n----------------------------";
        }
        frmReserva.areaResultados.setText(resultado);
    }
}
