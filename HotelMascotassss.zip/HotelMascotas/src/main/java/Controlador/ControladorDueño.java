/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.DueñoMascota;
import Vista.JFDueño;
import Vista.JFMain;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 *
 * @author Estudiante
 */
public class ControladorDueño implements ActionListener {
    private JFMain jfMain;
    private JFDueño frmDueño;
    private ArrayList<DueñoMascota> listaDueños;

    public ArrayList<DueñoMascota> getListaDueños() {
        return listaDueños;
    }

    public ControladorDueño(JFDueño frmDueño, JFMain jfMain) {
        this.jfMain = jfMain;
        this.frmDueño = frmDueño;
        this.listaDueños = new ArrayList<>();
        this.frmDueño.btnGuardar.addActionListener(this);
        this.frmDueño.btnLimpiar.addActionListener(this);
        this.frmDueño.btnMostrar.addActionListener(this);
        this.frmDueño.btAtras.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmDueño.btnGuardar) {
            guardarDueño();
        }
        if (e.getSource() == frmDueño.btnLimpiar) {
            limpiarCampos();
        }
        if (e.getSource() == frmDueño.btnMostrar) {
            mostrarDueños();
        }
        if (e.getSource() == frmDueño.btAtras) {
            this.jfMain.setVisible(true);
            this.limpiarCampos();
            this.frmDueño.areaResultados.setText("");
            this.frmDueño.setVisible(false);
        }
    }

    private void guardarDueño() {
        String nombre = frmDueño.txtNombre.getText();
        String apellido = frmDueño.txtApellido.getText();
        String telefono = frmDueño.txtTelefono.getText();
        String correo = frmDueño.txtCorreo.getText();

        if (nombre.isEmpty() || apellido.isEmpty() || telefono.isEmpty() || correo.isEmpty()) {
            frmDueño.areaResultados.setText("Todos los campos son obligatorios");
            return;
        }

        for (DueñoMascota d : listaDueños) {
            if (d.getCorreo().equalsIgnoreCase(correo)) {
                frmDueño.areaResultados.setText("Ya existe un dueño registrado con ese correo");
                return;
            }
        }

        DueñoMascota dueño = new DueñoMascota(nombre, apellido, telefono, correo);
        listaDueños.add(dueño);
        frmDueño.areaResultados.setText("Dueño registrado correctamente");
        limpiarCampos();
    }

    private void limpiarCampos() {
        frmDueño.txtNombre.setText("");
        frmDueño.txtApellido.setText("");
        frmDueño.txtTelefono.setText("");
        frmDueño.txtCorreo.setText("");
        frmDueño.txtNombre.requestFocus();
    }

    private void mostrarDueños() {
        if (listaDueños.isEmpty()) {
            frmDueño.areaResultados.setText("No hay dueños registrados");
            return;
        }
        String resultado = "";
        for (DueñoMascota d : listaDueños) {
            resultado += "\n=== DUEÑO ===";
            resultado += "\nNombre: " + d.getNombre() + " " + d.getApellido();
            resultado += "\nTeléfono: " + d.getTelefono();
            resultado += "\nCorreo: " + d.getCorreo();
            resultado += "\n----------------------------";
        }
        frmDueño.areaResultados.setText(resultado);
    }
}
