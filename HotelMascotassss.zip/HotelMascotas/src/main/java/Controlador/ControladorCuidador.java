/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Cuidador;
import Vista.JFCuidador;
import Vista.JFMain;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 *
 * @author Estudiante
 */
public class ControladorCuidador implements ActionListener {
    private JFMain jfMain;
    private JFCuidador frmCuidador;
    private ArrayList<Cuidador> listaCuidadores;

    public ArrayList<Cuidador> getListaCuidadores() {
        return listaCuidadores;
    }

    public ControladorCuidador(JFCuidador frmCuidador, JFMain jfMain) {
        this.jfMain = jfMain;
        this.frmCuidador = frmCuidador;
        this.listaCuidadores = new ArrayList<>();
        this.frmCuidador.btnGuardar.addActionListener(this);
        this.frmCuidador.btnLimpiar.addActionListener(this);
        this.frmCuidador.btnMostrar.addActionListener(this);
        this.frmCuidador.btAtras.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmCuidador.btnGuardar) {
            guardarCuidador();
        }
        if (e.getSource() == frmCuidador.btnLimpiar) {
            limpiarCampos();
        }
        if (e.getSource() == frmCuidador.btnMostrar) {
            mostrarCuidadores();
        }
        if (e.getSource() == frmCuidador.btAtras) {
            this.jfMain.setVisible(true);
            this.limpiarCampos();
            this.frmCuidador.areaResultados.setText("");
            this.frmCuidador.setVisible(false);
        }
    }

    private void guardarCuidador() {
        String nombre = frmCuidador.txtNombre.getText();
        String apellido = frmCuidador.txtApellido.getText();
        String nivel = frmCuidador.boxNivel.getSelectedItem().toString();
        String especies = "";
        if(frmCuidador.chkCanino.isSelected()) especies += "CANINO;";
        if(frmCuidador.chkFelino.isSelected()) especies += "FELINO;";
        if(frmCuidador.chkAve.isSelected()) especies += "AVE;";
        if(frmCuidador.chkRoedor.isSelected()) especies += "ROEDOR;";
        if(frmCuidador.chkReptil.isSelected()) especies += "REPTIL;";

        if (nombre.isEmpty() || apellido.isEmpty() || especies.isEmpty()) {
            frmCuidador.areaResultados.setText("Todos los campos son obligatorios");
            return;
        }

        Cuidador cuidador = new Cuidador(nombre, apellido, nivel, especies);
        listaCuidadores.add(cuidador);
        frmCuidador.areaResultados.setText("Cuidador registrado correctamente");
        limpiarCampos();
    }

    private void limpiarCampos() {
        frmCuidador.txtNombre.setText("");
        frmCuidador.txtApellido.setText("");
        frmCuidador.chkCanino.setSelected(false);
        frmCuidador.chkFelino.setSelected(false);
        frmCuidador.chkAve.setSelected(false);
        frmCuidador.chkRoedor.setSelected(false);
        frmCuidador.chkReptil.setSelected(false);
        frmCuidador.boxNivel.setSelectedIndex(0);
        frmCuidador.txtNombre.requestFocus();
    }

    private void mostrarCuidadores() {
        if (listaCuidadores.isEmpty()) {
            frmCuidador.areaResultados.setText("No hay cuidadores registrados");
            return;
        }
        String resultado = "";
        for (Cuidador c : listaCuidadores) {
            resultado += "\n=== CUIDADOR ===";
            resultado += "\nNombre: " + c.getNombre() + " " + c.getApellido();
            resultado += "\nNivel: " + c.getNivelExperiencia();
            resultado += "\nEspecies que atiende: " + c.getEspecies();
            resultado += "\nDisponible: " + (c.isDisponible() ? "Sí" : "No");
            resultado += "\n----------------------------";
        }
        frmCuidador.areaResultados.setText(resultado);
    }
}
