/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.awt.event.ActionEvent;
import Vista.*;
import Modelo.*;
import Controlador.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;


/**
 *
 * @author USUARIO
 */
public class ControladorMain implements ActionListener{
    private JFMain frmMain;
    private JFReserva frmReserva;
    private JFMascota frmMascota;
    private JFDueño frmDueño;
    private JFCuidador frmCuidador = new JFCuidador();
    
    public ControladorMain(JFMain frmMain) {
        this.frmMain = frmMain;
        this.frmMain.btCuidador.addActionListener(this);
        this.frmMain.btDueno.addActionListener(this);
        this.frmMain.btMascota.addActionListener(this);
        this.frmMain.btReserva.addActionListener(this);
        this.frmMain.btSalir.addActionListener(this);
        
        frmCuidador = new JFCuidador();
        frmDueño = new JFDueño();
        frmReserva = new JFReserva();
        frmMascota = new JFMascota();
        frmCuidador.setVisible(false);
        frmDueño.setVisible(false);
        frmReserva.setVisible(false);
        frmMascota.setVisible(false);
        inicializarForms();
    }
    
    private void inicializarForms(){
        ControladorCuidador ctrlCuidador = new ControladorCuidador(frmCuidador, this.frmMain);
        ControladorDueño ctrlDueño = new ControladorDueño(frmDueño, this.frmMain);
        ControladorMascota ctrlMascota = new ControladorMascota(frmMascota, ctrlDueño, this.frmMain);
        ControladorReserva ctrlReserva = new ControladorReserva(frmReserva, ctrlMascota, ctrlCuidador, this.frmMain);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == frmMain.btCuidador) {
            frmCuidador.setVisible(true);
            frmMain.setVisible(false);
        }
        if (e.getSource() == frmMain.btDueno) {
            frmDueño.setVisible(true);
            frmMain.setVisible(false);
        }
        if (e.getSource() == frmMain.btMascota) {
            
            frmMascota.setVisible(true);
            frmMain.setVisible(false);
        }
        if (e.getSource() == frmMain.btReserva) {
            frmReserva.setVisible(true);
            frmMain.setVisible(false);
        }
        if (e.getSource() == frmMain.btSalir) {
            System.exit(0);
        }
    }
}
