/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package main;
import Vista.JFVoto;
import Controlador.ControladorVotos;
import java.util.ArrayList;
import Modelo.Personero;
import Modelo.Representante;
/**
 *
 * @author Usuario
 */
public class ColegioAlegria {

    public static void main(String[] args) {
        JFVoto frmVoto = new JFVoto();
        ArrayList<Personero> listaPersonerosC = new ArrayList<>();
        ArrayList<Representante> listaRepresentantesC = new ArrayList<>();
        ControladorVotos ctrl = new ControladorVotos(frmVoto, listaPersonerosC, listaRepresentantesC);
        frmVoto.setVisible(true);
    }
}
