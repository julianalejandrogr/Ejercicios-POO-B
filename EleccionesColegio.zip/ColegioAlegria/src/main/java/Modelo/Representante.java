/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;


public class Representante extends Candidato {
    private Formula estudiante;

    public Representante( int numeroTarjeton, String nombre, String apellido, String grado, String lema,Formula estudiante) {
        super(numeroTarjeton, nombre, apellido, grado, lema);
        this.estudiante = estudiante;
    }

    public Formula getEstudiante() {
        return estudiante;
    }

    public void setEstudiante(Formula estudiante) {
        this.estudiante = estudiante;
    }

    public int getNumeroTarjeton() {
        return numeroTarjeton;
    }

    public void setNumeroTarjeton(int numeroTarjeton) {
        this.numeroTarjeton = numeroTarjeton;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

    public String getLema() {
        return lema;
    }

    public void setLema(String lema) {
        this.lema = lema;
    }

    public int getVotosObtenidos() {
        return votosObtenidos;
    }

    public void setVotosObtenidos(int votosObtenidos) {
        this.votosObtenidos = votosObtenidos;
    }

    @Override
    public String toString() {
        return super.toString()+" "+"Formula: " + estudiante;
    }
    

    

    
}
