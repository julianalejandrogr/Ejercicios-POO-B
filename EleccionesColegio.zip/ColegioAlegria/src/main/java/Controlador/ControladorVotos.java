
package Controlador;
import java.util.ArrayList;
import Modelo.Personero;
import Modelo.Representante;
import Modelo.Animal;
import Modelo.Tipo;
import Modelo.Formula;
import Vista.JFVoto;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultComboBoxModel;




public class ControladorVotos implements ActionListener{
    private JFVoto frmVoto;
    private ArrayList<Personero> listaPersoneros;
    private ArrayList<Representante> listaRepresentante;
    

    public ControladorVotos(JFVoto frmVoto, ArrayList<Personero> listaPersoneros, ArrayList<Representante> listaRepresentante) {
        this.frmVoto = frmVoto;
        this.listaPersoneros = listaPersoneros;
        this.listaRepresentante = listaRepresentante;
        frmVoto.btnVotarPersonero.addActionListener(this);
        frmVoto.btnVotarRepresentante.addActionListener(this);
        frmVoto.btnResultadoPersonero.addActionListener(this);
        frmVoto.btnResultadoRepresentante.addActionListener(this);
        CargarComboPersonero();
        CargarComboRepresentante();
    }
    

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == frmVoto.btnVotarPersonero){
            VotoPersonero();
        }
        if(e.getSource() == frmVoto.btnVotarRepresentante){
            VotoRepresentante();
        }
        if(e.getSource() == frmVoto.btnResultadoPersonero){
            ResultadoPersoneros();
        }
        if(e.getSource() == frmVoto.btnResultadoRepresentante){
            ResultadoRepresentantes();
        }
    }
    public void VotoPersonero(){
        Personero pSeleccionado = (Personero) frmVoto.cmbPersoneros.getSelectedItem();
        
        if (pSeleccionado != null) {
            pSeleccionado.setVotosObtenidos(pSeleccionado.getVotosObtenidos() + 1);
            frmVoto.txtMostrarPersonero.setText("Voto registrado");
        }
            
    }
    public void VotoRepresentante(){
        Representante rSeleccionado = (Representante) frmVoto.cmbRepresentante.getSelectedItem();
        
        if (rSeleccionado != null) {
            rSeleccionado.setVotosObtenidos(rSeleccionado.getVotosObtenidos() + 1);
            frmVoto.txtMostrarResultado.setText("Voto registrado");
        }
    }
    public void ResultadoPersoneros(){
        if (listaPersoneros.isEmpty()) {
            frmVoto.txtMostrarPersonero.setText("No hay votos registrados");
            return;
        }

        Personero ganador = null;
        Personero menorVotacion = null;
        int poblacionElectoral = 0; 
        
        StringBuilder resultados = new StringBuilder("=== RESULTADOS PERSONERO ===\n\n");
        resultados.append("Votos por opción:\n");
        
        for (Personero p : listaPersoneros) {
            resultados.append("- ").append(p.getNombre()).append(" ").append(p.getApellido()).append(": ").append(p.getVotosObtenidos()).append(" votos.\n");
            
            poblacionElectoral += p.getVotosObtenidos(); 
            if (p.getNumeroTarjeton() == 0 || p.getNumeroTarjeton() == 999) {
                continue; 
            }

            if (ganador == null) {
                ganador = p;
                menorVotacion = p;
            } 
            else {
                if (p.getVotosObtenidos() > ganador.getVotosObtenidos()) {
                    ganador = p;
                }
                if (p.getVotosObtenidos() < menorVotacion.getVotosObtenidos()) {
                    menorVotacion = p;
                }
            }
            }
            if (ganador != null) {
            resultados.append("Ganador: ").append(ganador.getNombre()).append(" ").append(ganador.getApellido()).append(" con ").append(ganador.getVotosObtenidos()).append(" votos.").append("\n");
            resultados.append("Menor Votación: ").append(menorVotacion.getNombre()).append(" ").append(menorVotacion.getApellido()).append(" con ").append(menorVotacion.getVotosObtenidos()).append(" votos.").append("\n");
        }
        resultados.append(" Total Votos Emitidos: ").append(poblacionElectoral);

        frmVoto.txtMostrarPersonero.setText(resultados.toString());
        }
    public void ResultadoRepresentantes(){
        if (listaRepresentante.isEmpty()) {
            frmVoto.txtMostrarResultado.setText("No hay votos registrados");
            return;
        }

        Representante ganador = null;
        Representante menorVotacion = null;
        int poblacionElectoral = 0; 
        
        StringBuilder resultados = new StringBuilder("=== RESULTADOS REPRESENTANTE ===\n\n");
        resultados.append("Votos por opción:\n");
        
        for (Representante r : listaRepresentante) {
            resultados.append("- ").append(r.getNombre()).append(" ").append(r.getApellido()).append(": ").append(r.getVotosObtenidos()).append(" votos.\n");
            
            poblacionElectoral += r.getVotosObtenidos(); 
            if (r.getNumeroTarjeton() == 0 || r.getNumeroTarjeton() == 999) {
                continue; 
            }

            if (ganador == null) {
                ganador = r;
                menorVotacion = r;
            } 
            else {
                if (r.getVotosObtenidos() > ganador.getVotosObtenidos()) {
                    ganador = r;
                }
                if (r.getVotosObtenidos() < menorVotacion.getVotosObtenidos()) {
                    menorVotacion = r;
                }
            }
            }
            if (ganador != null) {
            resultados.append("Ganador: ").append(ganador.getNombre()).append(" ").append(ganador.getApellido()).append(" con ").append(ganador.getVotosObtenidos()).append(" votos.").append("\n");
            resultados.append("Menor Votación: ").append(menorVotacion.getNombre()).append(" ").append(menorVotacion.getApellido()).append(" con ").append(menorVotacion.getVotosObtenidos()).append(" votos.").append("\n");
        }
        resultados.append(" Total Votos Emitidos: ").append(poblacionElectoral);

        frmVoto.txtMostrarResultado.setText(resultados.toString());
    }
    public void CargarComboPersonero(){
        Animal mascotaLuis = new Animal("01", "Tigre", "Macho", 4, "Garras Grandes", Tipo.TERRESTRE);
        Animal mascotaLucia = new Animal("02", "Halcón", "Hembra", 6, "Astuta", Tipo.AEREO);
        listaPersoneros.add(new Personero(0, "Voto en", "Blanco", "", "",null));
        listaPersoneros.add(new Personero(999, "Voto", "Nulo", "", "",null));
        listaPersoneros.add(new Personero(1, "Luis", "Acuña", "11A", "El futuro es nuestro",mascotaLuis));
        listaPersoneros.add(new Personero( 2, "Lucia", "Peñaranda", "11B", "Nuestro presente nos motiva",mascotaLucia));
        DefaultComboBoxModel<Personero> personero = new DefaultComboBoxModel<>();
        for(Personero p: listaPersoneros){
            personero.addElement(p);
        }
        frmVoto.cmbPersoneros.setModel(personero);
        
    }
    public void CargarComboRepresentante(){
        Formula estudianteDiego = new Formula("Julian", "115", "8A");
        Formula estudianteAlejandro = new Formula("Alejandra", "111", "8B");
        listaRepresentante.add(new Representante(0, "Voto", "en Blanco", "", "", null));
        listaRepresentante.add(new Representante(999, "Voto", "Nulo", "", "", null));
        listaRepresentante.add(new Representante( 1, "Diego", "Covilla", "8A", "Lo que se promete se cumple",estudianteDiego));
        listaRepresentante.add(new Representante(2, "Alejandro", "Ramirez", "8B", "Respeto y tolerancia", estudianteAlejandro));
        DefaultComboBoxModel<Representante> representante= new DefaultComboBoxModel<>();
        for(Representante r: listaRepresentante){
            representante.addElement(r);
        }
        frmVoto.cmbRepresentante.setModel(representante);
    }
}
