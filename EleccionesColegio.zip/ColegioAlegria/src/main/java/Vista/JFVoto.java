/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;
import Modelo.Representante;
import Modelo.Personero;

/**
 *
 * @author Usuario
 */
public class JFVoto extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(JFVoto.class.getName());

    /**
     * Creates new form JFVoto
     */
    public JFVoto() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        pnVoto = new javax.swing.JPanel();
        pnPersonero = new javax.swing.JPanel();
        cmbPersoneros = new javax.swing.JComboBox<>();
        btnVotarPersonero = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtMostrarPersonero = new javax.swing.JTextArea();
        btnResultadoPersonero = new javax.swing.JButton();
        pnRepresentante = new javax.swing.JPanel();
        cmbRepresentante = new javax.swing.JComboBox<>();
        btnVotarRepresentante = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtMostrarResultado = new javax.swing.JTextArea();
        btnResultadoRepresentante = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 464, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 367, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(jPanel1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnVoto.setBackground(new java.awt.Color(255, 255, 255));
        pnVoto.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "REGISTRO VOTOS", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N

        pnPersonero.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "PERSONERO", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N

        cmbPersoneros.setBackground(new java.awt.Color(204, 204, 204));
        cmbPersoneros.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N

        btnVotarPersonero.setBackground(new java.awt.Color(204, 204, 204));
        btnVotarPersonero.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnVotarPersonero.setText("Votar");

        txtMostrarPersonero.setColumns(20);
        txtMostrarPersonero.setRows(5);
        jScrollPane2.setViewportView(txtMostrarPersonero);

        btnResultadoPersonero.setBackground(new java.awt.Color(153, 153, 153));
        btnResultadoPersonero.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnResultadoPersonero.setText("Resultado");

        javax.swing.GroupLayout pnPersoneroLayout = new javax.swing.GroupLayout(pnPersonero);
        pnPersonero.setLayout(pnPersoneroLayout);
        pnPersoneroLayout.setHorizontalGroup(
            pnPersoneroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnPersoneroLayout.createSequentialGroup()
                .addGroup(pnPersoneroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnPersoneroLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(cmbPersoneros, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnPersoneroLayout.createSequentialGroup()
                        .addGap(101, 101, 101)
                        .addComponent(btnVotarPersonero)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(pnPersoneroLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 270, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(pnPersoneroLayout.createSequentialGroup()
                .addGap(99, 99, 99)
                .addComponent(btnResultadoPersonero)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnPersoneroLayout.setVerticalGroup(
            pnPersoneroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnPersoneroLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cmbPersoneros, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnVotarPersonero)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnResultadoPersonero)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pnRepresentante.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "REPRESENTANTE", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 12))); // NOI18N

        cmbRepresentante.setBackground(new java.awt.Color(204, 204, 204));
        cmbRepresentante.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N

        btnVotarRepresentante.setBackground(new java.awt.Color(204, 204, 204));
        btnVotarRepresentante.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnVotarRepresentante.setText("Votar");

        txtMostrarResultado.setColumns(20);
        txtMostrarResultado.setRows(5);
        jScrollPane4.setViewportView(txtMostrarResultado);

        btnResultadoRepresentante.setBackground(new java.awt.Color(153, 153, 153));
        btnResultadoRepresentante.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        btnResultadoRepresentante.setText("Resultado");

        javax.swing.GroupLayout pnRepresentanteLayout = new javax.swing.GroupLayout(pnRepresentante);
        pnRepresentante.setLayout(pnRepresentanteLayout);
        pnRepresentanteLayout.setHorizontalGroup(
            pnRepresentanteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnRepresentanteLayout.createSequentialGroup()
                .addGroup(pnRepresentanteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnRepresentanteLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(cmbRepresentante, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pnRepresentanteLayout.createSequentialGroup()
                        .addGap(98, 98, 98)
                        .addComponent(btnVotarRepresentante)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(pnRepresentanteLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 262, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(pnRepresentanteLayout.createSequentialGroup()
                .addGap(99, 99, 99)
                .addComponent(btnResultadoRepresentante)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnRepresentanteLayout.setVerticalGroup(
            pnRepresentanteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnRepresentanteLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cmbRepresentante, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnVotarRepresentante)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnResultadoRepresentante)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout pnVotoLayout = new javax.swing.GroupLayout(pnVoto);
        pnVoto.setLayout(pnVotoLayout);
        pnVotoLayout.setHorizontalGroup(
            pnVotoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnVotoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnPersonero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnRepresentante, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        pnVotoLayout.setVerticalGroup(
            pnVotoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnVotoLayout.createSequentialGroup()
                .addGroup(pnVotoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(pnPersonero, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnRepresentante, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 111, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(74, 74, 74))
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnVoto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 7, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnVoto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnResultadoPersonero;
    public javax.swing.JButton btnResultadoRepresentante;
    public javax.swing.JButton btnVotarPersonero;
    public javax.swing.JButton btnVotarRepresentante;
    public javax.swing.JComboBox<Personero> cmbPersoneros;
    public javax.swing.JComboBox<Representante> cmbRepresentante;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    public javax.swing.JPanel pnPersonero;
    public javax.swing.JPanel pnRepresentante;
    public javax.swing.JPanel pnVoto;
    public javax.swing.JTextArea txtMostrarPersonero;
    public javax.swing.JTextArea txtMostrarResultado;
    // End of variables declaration//GEN-END:variables
}
